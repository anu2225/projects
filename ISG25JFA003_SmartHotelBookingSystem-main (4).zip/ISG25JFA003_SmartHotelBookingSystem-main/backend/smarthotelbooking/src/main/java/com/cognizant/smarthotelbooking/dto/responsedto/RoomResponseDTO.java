package com.cognizant.smarthotelbooking.dto.responsedto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoomResponseDTO {
    private Long roomId;
    private String type;
    private double price;
    private boolean availability;
    private String features;
    private Long hotelId;
}



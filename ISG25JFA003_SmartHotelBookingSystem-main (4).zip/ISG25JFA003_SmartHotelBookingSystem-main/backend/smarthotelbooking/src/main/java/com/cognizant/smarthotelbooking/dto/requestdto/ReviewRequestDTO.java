package com.cognizant.smarthotelbooking.dto.requestdto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ReviewRequestDTO {
    private Long userId;
    @NotNull(message = "Hotel id cannot be null")
    private Long hotelId;
    @NotNull(message = "rating cannot be null")
    @Max(value = 5,message = "rating should be given out of 5")
    private double rating;
    @NotBlank(message = "Comment cannot be empty")
    private String comment;
}

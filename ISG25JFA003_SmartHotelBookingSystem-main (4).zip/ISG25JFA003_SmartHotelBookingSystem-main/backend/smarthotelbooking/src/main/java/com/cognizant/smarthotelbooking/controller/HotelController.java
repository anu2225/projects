package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.requestdto.HotelRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.HotelResponseDTO;
import com.cognizant.smarthotelbooking.service.HotelService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hotels")
@RequiredArgsConstructor
@Slf4j
public class HotelController {

    private final HotelService hotelService;

    @PreAuthorize("hasRole('MANAGER')")
    @PostMapping
    public ResponseEntity<HotelResponseDTO> createHotel(@RequestBody HotelRequestDTO dto) {
        return ResponseEntity.ok(hotelService.createHotel(dto));
    }

    @PreAuthorize("hasAnyRole('USER','MANAGER','ADMIN')")
    @GetMapping
    public ResponseEntity<List<HotelResponseDTO>> getAllHotels() {
        log.info("Fetching all hotels");
        return ResponseEntity.ok(hotelService.getAllHotels());
    }

    @PreAuthorize("hasAnyRole('USER','MANAGER','ADMIN')")
    @GetMapping("/{id}")
    public ResponseEntity<HotelResponseDTO> getHotelById(@PathVariable Long id) {
        log.info("Getting hotel with hotelId {}", id);
        return ResponseEntity.ok(hotelService.getHotelById(id));
    }

    @PreAuthorize("hasRole('MANAGER')")
    @PutMapping("/{id}")
    public ResponseEntity<HotelResponseDTO> updateHotelById(@PathVariable Long id, @RequestBody HotelRequestDTO dto) {
        return ResponseEntity.ok(hotelService.updateHotel(id, dto));
    }

    @PreAuthorize("hasRole('MANAGER')")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteHotel(@PathVariable Long id) {
        hotelService.deleteHotel(id);
        return ResponseEntity.ok("Hotel deleted");
    }

    @PreAuthorize("hasAnyRole('USER','MANAGER','ADMIN')")
    @GetMapping("/search")
    public ResponseEntity<List<HotelResponseDTO>> searchByLocation(@RequestParam String location) {
        log.info("Fetching Hotel from location {}", location);
        return ResponseEntity.ok(hotelService.searchByLocation(location));
    }

    @PreAuthorize("hasAnyRole('USER','MANAGER','ADMIN')")
    @GetMapping("/filter")
    public ResponseEntity<List<HotelResponseDTO>> filterByRating(@RequestParam Double rating) {
        return ResponseEntity.ok(hotelService.filterByRating(rating));
    }
}
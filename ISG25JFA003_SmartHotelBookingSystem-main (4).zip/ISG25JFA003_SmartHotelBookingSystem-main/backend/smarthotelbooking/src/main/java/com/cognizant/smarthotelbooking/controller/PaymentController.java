package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.requestdto.PaymentRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.PaymentResponseDTO;
import com.cognizant.smarthotelbooking.entity.Payment;
import com.cognizant.smarthotelbooking.service.PaymentService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
@Slf4j
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/process")
    public ResponseEntity<PaymentResponseDTO> processPayment(@Valid @RequestBody PaymentRequestDTO paymentRequest) {
        log.info("Processing payment for booking ID: {}", paymentRequest.getBookingId());
          PaymentResponseDTO payment = paymentService.processPayment(paymentRequest);
            return ResponseEntity.ok(payment);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/getPayments")
    public ResponseEntity<List<Payment>> getAllPayments() {
        return ResponseEntity.ok(paymentService.getAllPayments());
    }

    @PreAuthorize("hasAnyRole('USER','ADMIN','MANAGER')")
    @GetMapping("/{paymentId}")
    public ResponseEntity<PaymentResponseDTO> getPayment(@PathVariable String paymentId) {
        log.info("Fetching payment with ID: {}", paymentId);
        PaymentResponseDTO payment = paymentService.getPaymentById(paymentId);
        return ResponseEntity.ok(payment);
    }
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<PaymentResponseDTO> getPaymentByBooking(@PathVariable String bookingId) {
        log.info("Fetching payment for booking ID: {}", bookingId);
        PaymentResponseDTO payment = paymentService.getPaymentByBookingId(bookingId);
        return ResponseEntity.ok(payment);
    }
}
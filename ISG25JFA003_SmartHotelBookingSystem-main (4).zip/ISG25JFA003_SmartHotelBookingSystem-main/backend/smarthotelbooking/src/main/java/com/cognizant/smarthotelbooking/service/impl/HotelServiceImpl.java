
package com.cognizant.smarthotelbooking.service.impl;

import com.cognizant.smarthotelbooking.dto.requestdto.HotelRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.HotelResponseDTO;
import com.cognizant.smarthotelbooking.entity.Hotel;
import com.cognizant.smarthotelbooking.entity.User;
import com.cognizant.smarthotelbooking.exception.HotelNotFoundException;
import com.cognizant.smarthotelbooking.exception.UserNotFoundException;
import com.cognizant.smarthotelbooking.repository.HotelRepository;
import com.cognizant.smarthotelbooking.repository.UserRepository;
import com.cognizant.smarthotelbooking.service.HotelService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class HotelServiceImpl implements HotelService {

    private final HotelRepository hotelRepository;
    private final UserRepository userRepository;


    @Override
    public HotelResponseDTO createHotel(HotelRequestDTO dto) {
        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
        User user = userRepository.findByEmail(email).orElseThrow(() -> new UserNotFoundException("User not found"));

        Hotel hotel = new Hotel();
        hotel.setName(dto.getName());
        hotel.setLocation(dto.getLocation());
        hotel.setAmenities(dto.getAmenities());
        hotel.setRating(dto.getRating());
        hotel.setManagerId(user.getUserId());
        Hotel saved = hotelRepository.save(hotel);
        return mapToDTO(saved);
    }

    @Override
    public HotelResponseDTO updateHotel(Long id, HotelRequestDTO dto) {
        Hotel hotel = hotelRepository.findById(id).orElseThrow(() -> new HotelNotFoundException("Hotel not found"));
        hotel.setName(dto.getName());
        hotel.setLocation(dto.getLocation());
        hotel.setAmenities(dto.getAmenities());
        hotel.setRating(dto.getRating());
//        hotel.setManagerId(dto.getManagerId());
        Hotel updated = hotelRepository.save(hotel);
        return mapToDTO(updated);
    }

    @Override
    public void deleteHotel(Long id) {
        hotelRepository.deleteById(id);
    }

    @Override
    public HotelResponseDTO getHotelById(Long id) {
        Hotel hotel = hotelRepository.findById(id).orElseThrow(() -> new HotelNotFoundException("Hotel not found"));
        return mapToDTO(hotel);
    }

    @Override
    public List<HotelResponseDTO> getAllHotels() {
        return hotelRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Override
    public List<HotelResponseDTO> searchByLocation(String location) {
        List<Hotel> hotels = hotelRepository.findByLocationContainingIgnoreCase(location);
        if (hotels.isEmpty()) {
            throw new HotelNotFoundException("No hotels found in location: " + location);
        }
        return hotels.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<HotelResponseDTO> filterByRating(Double minRating) {
        List<Hotel> hotels = hotelRepository.findByRatingGreaterThanEqual(minRating);
        if (hotels.isEmpty()) {
            throw new HotelNotFoundException("No hotels found with a rating of " + minRating + " or higher.");
        }
        return hotels.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    private HotelResponseDTO mapToDTO(Hotel h) {
        return new HotelResponseDTO(h.getHotelId(), h.getName(), h.getLocation(), h.getAmenities(), h.getRating(), h.getManagerId());
    }
}

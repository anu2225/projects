package com.cognizant.smarthotelbooking.dto.responsedto;

import lombok.Data;

@Data
public class AuthResponseDTO {
    private String token;
    private int userId;
    private String userRole;

    public AuthResponseDTO(String token, int userId, String userRole) {
        this.token =  token;
        this.userId = userId;
        this.userRole = userRole;
    }
}

package com.cognizant.smarthotelbooking.entity.enums;

public enum PaymentStatus {
    Pending,
    Success
}

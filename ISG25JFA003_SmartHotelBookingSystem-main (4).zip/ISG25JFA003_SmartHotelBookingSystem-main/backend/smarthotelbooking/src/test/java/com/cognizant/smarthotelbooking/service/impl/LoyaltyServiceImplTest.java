package com.cognizant.smarthotelbooking.service.impl;

import com.cognizant.smarthotelbooking.dto.requestdto.LoyaltyRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.LoyaltyResponseDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.LoyaltyTransactionDTO;
import com.cognizant.smarthotelbooking.entity.*;
import com.cognizant.smarthotelbooking.repository.*;
import com.cognizant.smarthotelbooking.entity.enums.Action;
import com.cognizant.smarthotelbooking.entity.enums.BookingStatus;
import com.cognizant.smarthotelbooking.exception.BookingNotFoundException;
import com.cognizant.smarthotelbooking.exception.UserNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LoyaltyServiceImplTest {

    @Mock
    private LoyaltyAccountRepository loyaltyAccountRepository;
    @Mock
    private LoyaltyTransactionRepository loyaltyTransactionRepository;
    @Mock
    private RedemptionRepository redemptionRepository;
    @Mock
    private UserRepository userRepository;
    @Mock
    private BookingRepository bookingRepository;
    @Mock
    private PaymentRepository paymentRepository;
    @Mock
    private SecurityContext securityContext;
    @Mock
    private Authentication authentication;

    @InjectMocks
    private LoyaltyServiceImpl loyaltyService;

    private User user;
    private LoyaltyAccount loyaltyAccount;
    private LoyaltyRequestDTO loyaltyRequestDTO;
    private Booking booking;
    private Payment payment;

    @BeforeEach
    void setUp() {
        user = new User();
        user.setUserId(1L);
        user.setEmail("test@test.com");

        loyaltyAccount = new LoyaltyAccount();
        loyaltyAccount.setUser(user);
        loyaltyAccount.setPointsBalance(100);

        booking = new Booking();
        booking.setBookingId(1L);

        payment = new Payment();
        payment.setPaymentId(1L);
        payment.setAmount(500.0);
        payment.setBooking(booking);

        loyaltyRequestDTO = new LoyaltyRequestDTO();
        loyaltyRequestDTO.setUserId(1L);
        loyaltyRequestDTO.setBookingId(1L);
        loyaltyRequestDTO.setPoints(50);
        loyaltyRequestDTO.setAmount(500.0);

        when(SecurityContextHolder.getContext()).thenReturn(securityContext);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getPrincipal()).thenReturn(user.getEmail());
    }

    @Test
    void getPointsBalance_shouldReturnLoyaltyResponseDTO() {
        when(loyaltyAccountRepository.findByUser_UserId(1L)).thenReturn(loyaltyAccount);

        LoyaltyResponseDTO result = loyaltyService.getPointsBalance(1L);

        assertNotNull(result);
        assertEquals(1L, result.getUserId());
        assertEquals(100, result.getPointsBalance());
        assertEquals("Points fetched successfully", result.getMessage());
        verify(loyaltyAccountRepository, times(1)).findByUser_UserId(1L);
    }

    @Test
    void redeemPoints_shouldRedeemPointsSuccessfully() {
        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.of(user));
        when(loyaltyAccountRepository.findByUser_UserId(1L)).thenReturn(loyaltyAccount);
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
        when(paymentRepository.findByBooking_BookingId(1L)).thenReturn(payment);

        LoyaltyResponseDTO result = loyaltyService.redeemPoints(loyaltyRequestDTO);

        assertNotNull(result);
        assertEquals(1L, result.getUserId());
        assertEquals(50, result.getPointsBalance());
        assertEquals("Points redeemed successfully", result.getMessage());
        assertEquals(BookingStatus.Confirmed, booking.getStatus());
        assertEquals(450.0, payment.getAmount());
        verify(loyaltyAccountRepository, times(1)).save(loyaltyAccount);
        verify(bookingRepository, times(1)).save(booking);
        verify(paymentRepository, times(1)).save(payment);
        verify(redemptionRepository, times(1)).save(any(Redemption.class));
        verify(loyaltyTransactionRepository, times(1)).save(any(LoyaltyTransaction.class));
    }

    @Test
    void redeemPoints_shouldThrowUserNotFoundException() {
        when(userRepository.findByEmail(anyString())).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> loyaltyService.redeemPoints(loyaltyRequestDTO));
    }

    @Test
    void redeemPoints_shouldThrowInsufficientPointsException() {
        loyaltyRequestDTO.setPoints(150);
        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.of(user));
        when(loyaltyAccountRepository.findByUser_UserId(1L)).thenReturn(loyaltyAccount);

        assertThrows(IllegalArgumentException.class, () -> loyaltyService.redeemPoints(loyaltyRequestDTO));
    }

    @Test
    void redeemPoints_shouldThrowBookingNotFoundException() {
        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.of(user));
        when(loyaltyAccountRepository.findByUser_UserId(1L)).thenReturn(loyaltyAccount);
        when(bookingRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(BookingNotFoundException.class, () -> loyaltyService.redeemPoints(loyaltyRequestDTO));
    }

    @Test
    void getTransactionHistory_shouldReturnListOfTransactions() {
        LoyaltyTransaction transaction = new LoyaltyTransaction();
        transaction.setAction(Action.EARN);
        transaction.setDescription("Test transaction");
        transaction.setPoints(50);
        transaction.setTimestamp(LocalDateTime.now());

        when(loyaltyTransactionRepository.findByUser_UserId(1L)).thenReturn(List.of(transaction));

        List<LoyaltyTransactionDTO> result = loyaltyService.getTransactionHistory(1L);

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals(Action.EARN, result.get(0).getAction());
        verify(loyaltyTransactionRepository, times(1)).findByUser_UserId(1L);
    }

    @Test
    void getTransactionHistory_shouldReturnEmptyListForNoTransactions() {
        when(loyaltyTransactionRepository.findByUser_UserId(1L)).thenReturn(Collections.emptyList());

        List<LoyaltyTransactionDTO> result = loyaltyService.getTransactionHistory(1L);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(loyaltyTransactionRepository, times(1)).findByUser_UserId(1L);
    }

    @Test
    void earnPoints_shouldEarnPointsSuccessfully() {
        when(loyaltyAccountRepository.findByUser_UserId(1L)).thenReturn(loyaltyAccount);

        LoyaltyResponseDTO result = loyaltyService.earnPoints(loyaltyRequestDTO);

        assertNotNull(result);
        assertEquals(1L, result.getUserId());
        assertEquals(150, result.getPointsBalance()); // 100 + (500 * 0.1) = 150
        assertEquals("Points earned successfully", result.getMessage());
        verify(loyaltyAccountRepository, times(1)).save(loyaltyAccount);
        verify(loyaltyTransactionRepository, times(1)).save(any(LoyaltyTransaction.class));
    }

    @Test
    void applyPointsToBooking_shouldApplyPointsSuccessfully() {
        when(loyaltyAccountRepository.findByUser_UserId(1L)).thenReturn(loyaltyAccount);
        loyaltyRequestDTO.setPoints(50);

        LoyaltyResponseDTO result = loyaltyService.applyPointsToBooking(loyaltyRequestDTO);

        assertNotNull(result);
        assertEquals(1L, result.getUserId());
        assertEquals(50, result.getPointsBalance()); // 100 - 50 = 50
        assertEquals("Points applied successfully", result.getMessage());
        verify(loyaltyAccountRepository, times(1)).save(loyaltyAccount);
        verify(loyaltyTransactionRepository, times(1)).save(any(LoyaltyTransaction.class));
    }

    @Test
    void applyPointsToBooking_shouldReturnInsufficientPointsMessage() {
        when(loyaltyAccountRepository.findByUser_UserId(1L)).thenReturn(loyaltyAccount);
        loyaltyRequestDTO.setPoints(150);

        LoyaltyResponseDTO result = loyaltyService.applyPointsToBooking(loyaltyRequestDTO);

        assertNotNull(result);
        assertEquals(1L, result.getUserId());
        assertEquals(100, result.getPointsBalance());
        assertEquals("Insufficient points to apply", result.getMessage());
        verify(loyaltyAccountRepository, never()).save(any(LoyaltyAccount.class));
        verify(loyaltyTransactionRepository, never()).save(any(LoyaltyTransaction.class));
    }
}
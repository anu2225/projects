package com.cognizant.smarthotelbooking.service.impl;

import com.cognizant.smarthotelbooking.dto.requestdto.ReviewRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.ReviewResponseDTO;
import com.cognizant.smarthotelbooking.entity.Hotel;
import com.cognizant.smarthotelbooking.entity.Review;
import com.cognizant.smarthotelbooking.entity.User;
import com.cognizant.smarthotelbooking.exception.HotelNotFoundException;
import com.cognizant.smarthotelbooking.exception.ReviewNotFoundException;
import com.cognizant.smarthotelbooking.exception.UserNotFoundException;
import com.cognizant.smarthotelbooking.repository.HotelRepository;
import com.cognizant.smarthotelbooking.repository.ReviewRepository;
import com.cognizant.smarthotelbooking.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReviewServiceImplTest {

    @Mock
    private UserRepository userRepository;
    @Mock
    private HotelRepository hotelRepository;
    @Mock
    private ReviewRepository reviewRepository;
    @Mock
    private SecurityContext securityContext;
    @Mock
    private Authentication authentication;

    @InjectMocks
    private ReviewServiceImpl reviewService;

    private User user;
    private Hotel hotel;
    private Review review;
    private ReviewRequestDTO reviewRequestDTO;

    @BeforeEach
    void setUp() {
        user = new User();
        user.setUserId(1L);
        user.setEmail("test@test.com");

        hotel = new Hotel();
        hotel.setHotelId(1L);

        review = new Review();
        review.setReviewId(1L);
        review.setUser(user);
        review.setHotel(hotel);
        review.setRating(5.0);
        review.setComment("Great hotel!");

        reviewRequestDTO = new ReviewRequestDTO();
        reviewRequestDTO.setHotelId(1L);
        reviewRequestDTO.setRating(5);
        reviewRequestDTO.setComment("Great hotel!");

        when(SecurityContextHolder.getContext()).thenReturn(securityContext);
        when(securityContext.getAuthentication()).thenReturn(authentication);
    }

    @Test
    void createReview_shouldCreateReviewSuccessfully() {
        when(authentication.getPrincipal()).thenReturn(user.getEmail());
        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.of(user));
        when(hotelRepository.findById(1L)).thenReturn(Optional.of(hotel));
        when(reviewRepository.save(any(Review.class))).thenReturn(review);

        ReviewResponseDTO result = reviewService.createReview(reviewRequestDTO);

        assertNotNull(result);
        assertEquals(5, result.getRating());
        assertEquals("Great hotel!", result.getComment());
        verify(userRepository, times(1)).findByEmail(user.getEmail());
        verify(hotelRepository, times(1)).findById(1L);
        verify(reviewRepository, times(1)).save(any(Review.class));
    }

    @Test
    void createReview_shouldThrowUserNotFoundException() {
        when(authentication.getPrincipal()).thenReturn(user.getEmail());
        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> reviewService.createReview(reviewRequestDTO));
    }

    @Test
    void createReview_shouldThrowHotelNotFoundException() {
        when(authentication.getPrincipal()).thenReturn(user.getEmail());
        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.of(user));
        when(hotelRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(HotelNotFoundException.class, () -> reviewService.createReview(reviewRequestDTO));
    }

    @Test
    void getReviewsByHotel_shouldReturnReviews() {
        when(reviewRepository.findByHotel_HotelId(1L)).thenReturn(List.of(review));

        List<ReviewResponseDTO> result = reviewService.getReviewsByHotel(1L);

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals("Great hotel!", result.get(0).getComment());
        verify(reviewRepository, times(1)).findByHotel_HotelId(1L);
    }

    @Test
    void getReviewsByHotel_shouldThrowReviewNotFoundException() {
        when(reviewRepository.findByHotel_HotelId(1L)).thenReturn(Collections.emptyList());

        assertThrows(ReviewNotFoundException.class, () -> reviewService.getReviewsByHotel(1L));
    }

    @Test
    void getReviewsByUser_shouldReturnReviews() {
        when(reviewRepository.findByUser_UserId(1L)).thenReturn(List.of(review));

        List<ReviewResponseDTO> result = reviewService.getReviewsByUser(1L);

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals("Great hotel!", result.get(0).getComment());
        verify(reviewRepository, times(1)).findByUser_UserId(1L);
    }

    @Test
    void getReviewsByUser_shouldThrowReviewNotFoundException() {
        when(reviewRepository.findByUser_UserId(1L)).thenReturn(Collections.emptyList());

        assertThrows(ReviewNotFoundException.class, () -> reviewService.getReviewsByUser(1L));
    }

    @Test
    void respondToReview_shouldUpdateReviewResponse() {
        String response = "Thank you for your feedback!";
        when(reviewRepository.findById(1L)).thenReturn(Optional.of(review));
        when(reviewRepository.save(any(Review.class))).thenReturn(review);

        ReviewResponseDTO result = reviewService.respondToReview(1L, response);

        assertNotNull(result);
        assertEquals(response, review.getResponse());
        verify(reviewRepository, times(1)).findById(1L);
        verify(reviewRepository, times(1)).save(review);
    }

    @Test
    void respondToReview_shouldThrowReviewNotFoundException() {
        when(reviewRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ReviewNotFoundException.class, () -> reviewService.respondToReview(1L, "response"));
    }

    @Test
    void updateResponse_shouldUpdateReviewResponse() {
        String response = "Updated response.";
        when(reviewRepository.findById(1L)).thenReturn(Optional.of(review));
        when(reviewRepository.save(any(Review.class))).thenReturn(review);

        ReviewResponseDTO result = reviewService.updateResponse(1L, response);

        assertNotNull(result);
        assertEquals(response, review.getResponse());
        verify(reviewRepository, times(1)).findById(1L);
        verify(reviewRepository, times(1)).save(review);
    }

    @Test
    void deleteReview_shouldDeleteReviewSuccessfully() {
        doNothing().when(reviewRepository).deleteById(1L);

        reviewService.deleteReview(1L);

        verify(reviewRepository, times(1)).deleteById(1L);
    }
}
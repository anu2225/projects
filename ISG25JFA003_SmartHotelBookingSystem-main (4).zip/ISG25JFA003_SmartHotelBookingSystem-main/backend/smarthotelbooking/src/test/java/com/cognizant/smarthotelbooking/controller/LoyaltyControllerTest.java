package com.cognizant.smarthotelbooking.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.cognizant.smarthotelbooking.dto.requestdto.LoyaltyRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.LoyaltyResponseDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.LoyaltyTransactionDTO;
import com.cognizant.smarthotelbooking.service.LoyaltyService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class LoyaltyControllerTest {

    private MockMvc mockMvc;

    @Mock
    private LoyaltyService loyaltyService;

    @InjectMocks
    private LoyaltyController loyaltyController;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(loyaltyController).build();
        objectMapper = new ObjectMapper();
    }

    @Test
    void getPointsBalance_shouldReturnPointsBalance() throws Exception {
        Long userId = 1L;
        LoyaltyResponseDTO responseDTO = new LoyaltyResponseDTO(userId, 100, "Points fetched successfully");
        when(loyaltyService.getPointsBalance(userId)).thenReturn(responseDTO);

        mockMvc.perform(get("/rewards/{userId}", userId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userId").value(userId))
                .andExpect(jsonPath("$.pointsBalance").value(100))
                .andExpect(jsonPath("$.message").value("Points fetched successfully"));

        verify(loyaltyService, times(1)).getPointsBalance(userId);
    }

    @Test
    void redeemPoints_shouldReturnRedeemedPoints() throws Exception {
        LoyaltyRequestDTO requestDTO = new LoyaltyRequestDTO();
        requestDTO.setPoints(50);
        requestDTO.setBookingId(1L);

        LoyaltyResponseDTO responseDTO = new LoyaltyResponseDTO(1L, 50, "Points redeemed successfully");
        when(loyaltyService.redeemPoints(any(LoyaltyRequestDTO.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/rewards/redeem")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userId").value(1L))
                .andExpect(jsonPath("$.pointsBalance").value(50))
                .andExpect(jsonPath("$.message").value("Points redeemed successfully"));

        verify(loyaltyService, times(1)).redeemPoints(any(LoyaltyRequestDTO.class));
    }

    @Test
    void getTransactionHistory_shouldReturnTransactionHistory() throws Exception {
        Long userId = 1L;
        LoyaltyTransactionDTO transaction1 = new LoyaltyTransactionDTO();
        transaction1.setDescription("Earned points");
        transaction1.setPoints(10);
        transaction1.setTimestamp(LocalDateTime.now());

        List<LoyaltyTransactionDTO> transactions = List.of(transaction1);
        when(loyaltyService.getTransactionHistory(userId)).thenReturn(transactions);

        mockMvc.perform(get("/rewards/history/{userId}", userId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].description").value("Earned points"))
                .andExpect(jsonPath("$[0].points").value(10));

        verify(loyaltyService, times(1)).getTransactionHistory(userId);
    }

    @Test
    void getTransactionHistory_shouldReturnEmptyList_whenNoTransactions() throws Exception {
        Long userId = 1L;
        when(loyaltyService.getTransactionHistory(userId)).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/rewards/history/{userId}", userId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isEmpty());

        verify(loyaltyService, times(1)).getTransactionHistory(userId);
    }

    @Test
    void earnPoints_shouldReturnEarnedPoints() throws Exception {
        LoyaltyRequestDTO requestDTO = new LoyaltyRequestDTO();
        requestDTO.setUserId(1L);
        requestDTO.setAmount(100.0);

        LoyaltyResponseDTO responseDTO = new LoyaltyResponseDTO(1L, 10, "Points earned successfully");
        when(loyaltyService.earnPoints(any(LoyaltyRequestDTO.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/rewards/earn")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userId").value(1L))
                .andExpect(jsonPath("$.pointsBalance").value(10))
                .andExpect(jsonPath("$.message").value("Points earned successfully"));

        verify(loyaltyService, times(1)).earnPoints(any(LoyaltyRequestDTO.class));
    }
}
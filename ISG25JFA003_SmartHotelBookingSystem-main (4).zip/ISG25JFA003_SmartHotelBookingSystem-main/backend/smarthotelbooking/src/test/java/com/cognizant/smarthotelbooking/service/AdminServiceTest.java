package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.UserRegistrationDTO;
import com.cognizant.smarthotelbooking.entity.User;
import com.cognizant.smarthotelbooking.exception.UserNotFoundException;
import com.cognizant.smarthotelbooking.repository.UserRepository;
import com.cognizant.smarthotelbooking.service.impl.AdminServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static com.cognizant.smarthotelbooking.entity.enums.Role.MANAGER;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AdminServiceTest {

    @InjectMocks
    private AdminServiceImpl adminService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Test
    void testCreateManager() {
        // Arrange
        UserRegistrationDTO request = new UserRegistrationDTO("New Manager", "manager@example.com", "password123", "1234567890", MANAGER);
        String encodedPassword = "encodedPassword123";

        when(passwordEncoder.encode(request.getPassword())).thenReturn(encodedPassword);

        // Act
        adminService.createManager(request);

        // Assert
        ArgumentCaptor<User> userCaptor = ArgumentCaptor.forClass(User.class);
        verify(userRepository, times(1)).save(userCaptor.capture());

        User capturedUser = userCaptor.getValue();
        assertThat(capturedUser.getName()).isEqualTo("New Manager");
        assertThat(capturedUser.getEmail()).isEqualTo("manager@example.com");
        assertThat(capturedUser.getRole()).isEqualTo(MANAGER);
        assertThat(capturedUser.getPassword()).isEqualTo(encodedPassword);
    }

    // Test for updateUserStatus - user found
    @Test
    void testUpdateUserStatus_UserFound() {
        // Arrange
        long userId = 1L;
        User user = new User();
        user.setUserId(userId);
        user.setActive(false);

        when(userRepository.findById(userId)).thenReturn(Optional.of(user));

        // Act
        adminService.updateUserStatus(userId, true);

        // Assert
        verify(userRepository, times(1)).save(user);
        assertThat(user.isActive()).isTrue();
    }

    // Test for updateUserStatus - user not found
    @Test
    void testUpdateUserStatus_UserNotFound() {
        // Arrange
        long userId = 99L;
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        // Assert & Act
        assertThrows(UserNotFoundException.class, () -> adminService.updateUserStatus(userId, true));
    }
}

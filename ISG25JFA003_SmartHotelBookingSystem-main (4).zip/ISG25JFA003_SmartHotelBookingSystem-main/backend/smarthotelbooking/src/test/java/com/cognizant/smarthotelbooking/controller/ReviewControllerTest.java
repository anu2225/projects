package com.cognizant.smarthotelbooking.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.cognizant.smarthotelbooking.dto.requestdto.ReviewRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.ReviewResponseDTO;
import com.cognizant.smarthotelbooking.service.ReviewService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class ReviewControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ReviewService reviewService;

    @InjectMocks
    private ReviewController reviewController;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(reviewController).build();
        objectMapper = new ObjectMapper();
    }

    @Test
    void submitReview_shouldCreateReviewAndReturnOk() throws Exception {
        ReviewRequestDTO requestDTO = new ReviewRequestDTO();
        requestDTO.setHotelId(1L);
        requestDTO.setRating(5);
        requestDTO.setComment("Excellent service!");

        ReviewResponseDTO responseDTO = new ReviewResponseDTO();
        responseDTO.setReviewId(1L);
        responseDTO.setRating(5);
        responseDTO.setComment("Excellent service!");

        when(reviewService.createReview(any(ReviewRequestDTO.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/api/reviews")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.reviewId").value(1L))
                .andExpect(jsonPath("$.rating").value(5))
                .andExpect(jsonPath("$.comment").value("Excellent service!"));

        verify(reviewService, times(1)).createReview(any(ReviewRequestDTO.class));
    }

    @Test
    void getReviewsByHotel_shouldReturnReviews() throws Exception {
        Long hotelId = 1L;
        ReviewResponseDTO review1 = new ReviewResponseDTO();
        review1.setReviewId(1L);
        review1.setRating(4);

        List<ReviewResponseDTO> reviews = List.of(review1);
        when(reviewService.getReviewsByHotel(hotelId)).thenReturn(reviews);

        mockMvc.perform(get("/api/reviews/hotel/{hotelId}", hotelId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].reviewId").value(1L))
                .andExpect(jsonPath("$[0].rating").value(4));

        verify(reviewService, times(1)).getReviewsByHotel(hotelId);
    }

    @Test
    void getReviewsByHotel_shouldReturnEmptyList_whenNoReviewsFound() throws Exception {
        Long hotelId = 1L;
        when(reviewService.getReviewsByHotel(hotelId)).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/reviews/hotel/{hotelId}", hotelId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isEmpty());

        verify(reviewService, times(1)).getReviewsByHotel(hotelId);
    }

    @Test
    void getReviewsByUser_shouldReturnReviews() throws Exception {
        Long userId = 1L;
        ReviewResponseDTO review1 = new ReviewResponseDTO();
        review1.setReviewId(1L);
        review1.setRating(5);

        List<ReviewResponseDTO> reviews = List.of(review1);
        when(reviewService.getReviewsByUser(userId)).thenReturn(reviews);

        mockMvc.perform(get("/api/reviews/user/{userId}", userId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].reviewId").value(1L))
                .andExpect(jsonPath("$[0].rating").value(5));

        verify(reviewService, times(1)).getReviewsByUser(userId);
    }

    @Test
    void respondToReview_shouldUpdateResponseAndReturnOk() throws Exception {
        Long reviewId = 1L;
        String response = "Thank you for your feedback.";
        ReviewResponseDTO responseDTO = new ReviewResponseDTO();
        responseDTO.setReviewId(1L);
        responseDTO.setResponse(response);

        when(reviewService.respondToReview(reviewId, response)).thenReturn(responseDTO);

        mockMvc.perform(post("/api/reviews/{reviewId}/response", reviewId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(response))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.reviewId").value(1L))
                .andExpect(jsonPath("$.response").value(response));

        verify(reviewService, times(1)).respondToReview(reviewId, response);
    }

    @Test
    void updateResponse_shouldUpdateResponseAndReturnOk() throws Exception {
        Long reviewId = 1L;
        String response = "Updated response.";
        ReviewResponseDTO responseDTO = new ReviewResponseDTO();
        responseDTO.setReviewId(1L);
        responseDTO.setResponse(response);

        when(reviewService.updateResponse(reviewId, response)).thenReturn(responseDTO);

        mockMvc.perform(put("/api/reviews/{reviewId}/response", reviewId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(response))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.reviewId").value(1L))
                .andExpect(jsonPath("$.response").value(response));

        verify(reviewService, times(1)).updateResponse(reviewId, response);
    }

    @Test
    void deleteReview_shouldDeleteReviewAndReturnOk() throws Exception {
        Long reviewId = 1L;
        doNothing().when(reviewService).deleteReview(reviewId);

        mockMvc.perform(delete("/api/reviews/{reviewId}", reviewId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").value("Review deleted successfully"));

        verify(reviewService, times(1)).deleteReview(reviewId);
    }
}
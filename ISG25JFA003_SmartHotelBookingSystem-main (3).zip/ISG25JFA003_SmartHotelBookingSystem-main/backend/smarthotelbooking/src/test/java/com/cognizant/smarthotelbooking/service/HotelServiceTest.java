package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.HotelRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.HotelResponseDTO;
import com.cognizant.smarthotelbooking.entity.Hotel;
import com.cognizant.smarthotelbooking.entity.User;
import com.cognizant.smarthotelbooking.repository.HotelRepository;
import com.cognizant.smarthotelbooking.repository.UserRepository;
import com.cognizant.smarthotelbooking.service.impl.HotelServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static com.cognizant.smarthotelbooking.entity.enums.Role.MANAGER;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;


class HotelServiceTest {

    @Mock
    private HotelRepository hotelRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private HotelServiceImpl hotelService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllHotels() {
        List<Hotel> hotels = Arrays.asList(
                new Hotel(1L, "Taj", "Mumbai", "Pool, Spa", 5.0, 101L),
                new Hotel(2L, "Oberoi", "Delhi", "Gym, WiFi", 4.5, 102L)
        );

        when(hotelRepository.findAll()).thenReturn(hotels);

        List<HotelResponseDTO> result = hotelService.getAllHotels();

        assertEquals(2, result.size());
        assertEquals("Taj", result.getFirst().getName());
    }

    @Test
    void testGetHotelById() {
        Hotel hotel = new Hotel(1L, "Taj", "Mumbai", "Pool, Spa", 5.0, 101L);

        when(hotelRepository.findById(1L)).thenReturn(Optional.of(hotel));

        HotelResponseDTO result = hotelService.getHotelById(1L);

        assertEquals("Taj", result.getName());
        assertEquals("Mumbai", result.getLocation());
    }

    @Test
    void testUpdateHotel() {
        HotelRequestDTO req = new HotelRequestDTO("Taj Updated", "Mumbai", "Pool, Spa", 5.0);
        Hotel existing = new Hotel(1L, "Taj", "Mumbai", "Pool, Spa", 5.0, 101L);
        Hotel updated = new Hotel(1L, "Taj Updated", "Mumbai", "Pool, Spa", 5.0, 101L);

        when(hotelRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(hotelRepository.save(any(Hotel.class))).thenReturn(updated);

        HotelResponseDTO result = hotelService.updateHotel(1L, req);

        assertEquals("Taj Updated", result.getName());
    }

    @Test
    void testDeleteHotel() {
        hotelService.deleteHotel(1L);
    }
}
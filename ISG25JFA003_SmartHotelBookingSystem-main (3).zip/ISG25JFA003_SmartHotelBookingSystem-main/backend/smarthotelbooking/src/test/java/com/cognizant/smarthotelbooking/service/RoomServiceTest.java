package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.RoomRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.RoomResponseDTO;
import com.cognizant.smarthotelbooking.entity.Hotel;
import com.cognizant.smarthotelbooking.entity.Room;
import com.cognizant.smarthotelbooking.exception.RoomNotFoundException;
import com.cognizant.smarthotelbooking.repository.HotelRepository;
import com.cognizant.smarthotelbooking.repository.RoomRepository;
import com.cognizant.smarthotelbooking.service.impl.RoomServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RoomServiceTest {

    @Mock
    private RoomRepository roomRepository;

    @Mock
    private HotelRepository hotelRepository; // IMPORTANT: RoomServiceImpl uses this

    @InjectMocks
    private RoomServiceImpl roomService;

    private Room room;
    private RoomRequestDTO roomRequestDTO;
    private Hotel hotel;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // build a Hotel entity that will be returned by hotelRepository.findById(...)
        hotel = new Hotel();
        hotel.setHotelId(10L);
        hotel.setName("TestHotel");
        hotel.setLocation("TestCity");
        hotel.setAmenities("A,B");
        hotel.setRating(4.0);
        hotel.setManagerId(100L);

        // Room entity (note: setHotel(hotel) because service expects room.getHotel())
        room = new Room();
        room.setRoomId(1L);
        room.setType("Deluxe");
        room.setPrice(2500.0);
        room.setAvailability(true);
        room.setFeatures("Sea view, AC, WiFi");
        room.setHotel(hotel);

        // Request DTO (no-args + setters as in your project)
        roomRequestDTO = new RoomRequestDTO();
        roomRequestDTO.setType("Deluxe");
        roomRequestDTO.setPrice(2500.0);
        roomRequestDTO.setAvailability(true);
        roomRequestDTO.setFeatures("Sea view, AC, WiFi");
        roomRequestDTO.setHotelId(10L);
    }

    @Test
    void testCreateRoom() {
        // service will call hotelRepository.findById(hotelId)
        when(hotelRepository.findById(10L)).thenReturn(Optional.of(hotel));
        // and then it will save the Room via roomRepository.save(...)
        when(roomRepository.save(any(Room.class))).thenReturn(room);

        RoomResponseDTO response = roomService.createRoom(roomRequestDTO);

        assertNotNull(response);
        assertEquals("Deluxe", response.getType());
        assertEquals(2500.0, response.getPrice());
        // verify save called once
        verify(roomRepository, times(1)).save(any(Room.class));
    }

    @Test
    void testGetRoomById_Found() {
        when(roomRepository.findById(1L)).thenReturn(Optional.of(room));

        RoomResponseDTO response = roomService.getRoomById(1L);

        assertNotNull(response);
        assertEquals("Deluxe", response.getType());
        assertTrue(response.isAvailability());
    }

    @Test
    void testGetRoomById_NotFound() {
        when(roomRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RoomNotFoundException.class, () -> roomService.getRoomById(1L));
    }

    @Test
    void testGetAllRooms() {
        when(roomRepository.findAll()).thenReturn(Arrays.asList(room));

        List<RoomResponseDTO> rooms = roomService.getAllRooms();

        assertEquals(1, rooms.size());
        assertEquals("Deluxe", rooms.get(0).getType());
    }

    @Test
    void testUpdateRoom() {
        // service reads existing room, updates fields, may read hotel if hotelId provided
        when(roomRepository.findById(1L)).thenReturn(Optional.of(room));
        when(hotelRepository.findById(10L)).thenReturn(Optional.of(hotel));
        when(roomRepository.save(any(Room.class))).thenReturn(room);

        RoomResponseDTO updated = roomService.updateRoom(1L, roomRequestDTO);

        assertEquals("Deluxe", updated.getType());
        assertEquals(2500.0, updated.getPrice());
    }
////
////    @Test
////    void testDeleteRoom() {
////        when(roomRepository.findById(1L)).thenReturn(Optional.of(room));
////
////        roomService.deleteRoom(1L);
////
////        verify(roomRepository, times(1)).delete(room);
    }

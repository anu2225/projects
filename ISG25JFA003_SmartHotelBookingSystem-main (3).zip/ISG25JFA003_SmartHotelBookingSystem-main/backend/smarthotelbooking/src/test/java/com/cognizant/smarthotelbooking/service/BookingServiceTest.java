package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.BookingRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.BookingResponseDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.BookingRoomResponseDTO;
import com.cognizant.smarthotelbooking.entity.Booking;
import com.cognizant.smarthotelbooking.entity.Payment;
import com.cognizant.smarthotelbooking.entity.Room;
import com.cognizant.smarthotelbooking.entity.User;
import com.cognizant.smarthotelbooking.entity.enums.BookingStatus;
import com.cognizant.smarthotelbooking.entity.enums.PaymentStatus;
import com.cognizant.smarthotelbooking.exception.BookingNotFoundException;
import com.cognizant.smarthotelbooking.exception.UserNotFoundException;
import com.cognizant.smarthotelbooking.repository.BookingRepository;
import com.cognizant.smarthotelbooking.repository.PaymentRepository;
import com.cognizant.smarthotelbooking.repository.RoomRepository;
import com.cognizant.smarthotelbooking.repository.UserRepository;
import com.cognizant.smarthotelbooking.service.impl.BookingServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BookingServiceTest {

    @InjectMocks
    private BookingServiceImpl bookingService;

    @Mock
    private BookingRepository bookingRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private RoomRepository roomRepository;

    @Mock
    private PaymentRepository paymentRepository;

    private User mockUser;
    private Booking mockBooking;
    private BookingRequestDTO mockBookingRequestDTO;
    private Room mockRoom;
    private Payment mockPayment;

    @BeforeEach
    void setUp() {
        mockUser = new User();
        mockUser.setUserId(1L);
        mockUser.setEmail("testuser@example.com");

        mockRoom = new Room();
        mockRoom.setRoomId(101L);
        mockRoom.setPrice(100.0);
        mockRoom.setType("Single");

        mockPayment = new Payment();
        mockPayment.setPaymentId(1L);
        mockPayment.setAmount(200.0);
        mockPayment.setPaymentStatus(PaymentStatus.PENDING);
        mockPayment.setPaymentMethod("Card");

        mockBooking = new Booking();
//        mockBooking.setBookingId(1L);
        mockBooking.setUser(mockUser);
        mockBooking.setRoomId(mockRoom.getRoomId());
        mockBooking.setCheckInDate(LocalDate.now().plusDays(5));
        mockBooking.setCheckOutDate(LocalDate.now().plusDays(7));
        mockBooking.setBookingDate(LocalDate.now());
        mockBooking.setStatus(BookingStatus.PENDING);
        mockBooking.setPayment(mockPayment);

        mockBookingRequestDTO = new BookingRequestDTO();
        mockBookingRequestDTO.setRoomId(mockRoom.getRoomId());
        mockBookingRequestDTO.setCheckInDate(LocalDate.now().plusDays(5));
        mockBookingRequestDTO.setCheckOutDate(LocalDate.now().plusDays(7));
    }

    @Test
    void createBooking_shouldCreateAndReturnBooking() {
        // Arrange
        Authentication authentication = mock(Authentication.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.getPrincipal()).thenReturn(mockUser.getEmail());

        // Configure mocks to return valid objects
        when(userRepository.findByEmail(mockUser.getEmail())).thenReturn(Optional.of(mockUser));
        when(roomRepository.findById(mockRoom.getRoomId())).thenReturn(Optional.of(mockRoom));
        when(bookingRepository.save(any(Booking.class))).thenReturn(mockBooking);
        when(paymentRepository.save(any(Payment.class))).thenReturn(mockPayment);

        // Act
        BookingResponseDTO result = bookingService.createBooking(mockBookingRequestDTO);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getBookingId()).isEqualTo(mockBooking.getBookingId());
        assertThat(result.getStatus()).isEqualTo(mockBooking.getStatus());
        verify(bookingRepository, times(1)).save(any(Booking.class));
        verify(paymentRepository, times(1)).save(any(Payment.class));
    }

    @Test
    void getBookingById_shouldReturnBookingDetails() {
        // Arrange
        BookingRoomResponseDTO responseDTO = new BookingRoomResponseDTO(
                1L, 1L, "Test User", 101L, "Single",
                LocalDate.now(), LocalDate.now(), LocalDate.now(), BookingStatus.PENDING);
        when(bookingRepository.findBookingDetailsById(1L)).thenReturn(responseDTO);

        // Act
        BookingRoomResponseDTO result = bookingService.getBookingById(1L);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getBookingId()).isEqualTo(1L);
        verify(bookingRepository, times(1)).findBookingDetailsById(1L);
    }

    @Test
    void getBookingById_shouldThrowExceptionForInvalidId() {
        // Arrange
        when(bookingRepository.findBookingDetailsById(99L)).thenReturn(null);

        // Assert
        assertThrows(BookingNotFoundException.class, () -> bookingService.getBookingById(99L));
    }

    @Test
    void getBookingsByUserId_shouldReturnBookings() {
        // Arrange
        when(userRepository.findById(1L)).thenReturn(Optional.of(mockUser));
        BookingResponseDTO responseDTO = new BookingResponseDTO(1L, 1L, 101L, LocalDate.now(), LocalDate.now(), LocalDate.now(), 200.0, BookingStatus.PENDING);
        when(bookingRepository.findByUser(mockUser)).thenReturn(Collections.singletonList(responseDTO));

        // Act
        List<BookingResponseDTO> result = bookingService.getBookingsByUserId(1L);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(1);
        assertThat(result.get(0).getUserId()).isEqualTo(1L);
        verify(bookingRepository, times(1)).findByUser(mockUser);
    }

    @Test
    void getBookingsByUserId_shouldThrowUserNotFoundException() {
        // Arrange
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        // Assert
        assertThrows(UserNotFoundException.class, () -> bookingService.getBookingsByUserId(99L));
    }

    @Test
    void updateBooking_shouldUpdateAndSaveBooking() {
        // Arrange
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(mockBooking));
        BookingRequestDTO updatedDto = new BookingRequestDTO();
        updatedDto.setCheckInDate(LocalDate.now().plusDays(10));
        updatedDto.setCheckOutDate(LocalDate.now().plusDays(12));

        // Act
        bookingService.updateBooking(String.valueOf(1L), updatedDto);

        // Assert
        verify(bookingRepository, times(1)).save(any(Booking.class));
        assertThat(mockBooking.getCheckInDate()).isEqualTo(updatedDto.getCheckInDate());
    }

    @Test
    void cancelBooking_shouldDeleteBooking() {
        // Arrange
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(mockBooking));

        // Act
        bookingService.cancelBooking(String.valueOf(1L));

        // Assert
        verify(bookingRepository, times(1)).deleteById(1L);
    }

    @Test
    void getAllBookings_shouldReturnAllBookings() {
        // Arrange
        when(bookingRepository.findAll()).thenReturn(Collections.singletonList(mockBooking));

        // Act
        List<BookingResponseDTO> result = bookingService.getAllBookings();

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(1);
        verify(bookingRepository, times(1)).findAll();
    }
}
package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.ReviewRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.ReviewResponseDTO;
import com.cognizant.smarthotelbooking.entity.Hotel;
import com.cognizant.smarthotelbooking.entity.Review;
import com.cognizant.smarthotelbooking.entity.User;
import com.cognizant.smarthotelbooking.exception.HotelNotFoundException;
import com.cognizant.smarthotelbooking.exception.ReviewNotFoundException;
import com.cognizant.smarthotelbooking.exception.UserNotFoundException;
import com.cognizant.smarthotelbooking.repository.HotelRepository;
import com.cognizant.smarthotelbooking.repository.ReviewRepository;
import com.cognizant.smarthotelbooking.repository.UserRepository;
import com.cognizant.smarthotelbooking.service.impl.ReviewServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReviewServiceTest {

    @Mock
    private UserRepository userRepository;
    @Mock
    private HotelRepository hotelRepository;
    @Mock
    private ReviewRepository reviewRepository;

    @InjectMocks
    private ReviewServiceImpl reviewService;

    // We'll use Nested classes to separate tests that need SecurityContext from those that don't.
    // This makes the test class cleaner and more focused.

    @Nested
    class CreateReviewTests {

        @Mock
        private SecurityContext securityContext;
        @Mock
        private Authentication authentication;

        @Test
        void createReview_shouldCreateReviewSuccessfully() {
            try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder = mockStatic(SecurityContextHolder.class)) {
                // Stubbing the static method inside the try block
                mockedSecurityContextHolder.when(SecurityContextHolder::getContext).thenReturn(securityContext);
                when(securityContext.getAuthentication()).thenReturn(authentication);
                when(authentication.getPrincipal()).thenReturn("test@test.com");

                User user = new User();
                user.setUserId(1L);
                user.setEmail("test@test.com");

                Hotel hotel = new Hotel();
                hotel.setHotelId(1L);

                Review review = new Review();
                review.setReviewId(1L);
                review.setRating(5.0);
                review.setComment("Great stay!");
                review.setTimestamp(LocalDateTime.now());
                review.setUser(user);
                review.setHotel(hotel);

                ReviewRequestDTO requestDTO = new ReviewRequestDTO();
                requestDTO.setHotelId(1L);
                requestDTO.setRating(5.0);
                requestDTO.setComment("Great stay!");

                when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.of(user));
                when(hotelRepository.findById(1L)).thenReturn(Optional.of(hotel));
                when(reviewRepository.save(any(Review.class))).thenReturn(review);

                ReviewResponseDTO response = reviewService.createReview(requestDTO);

                assertNotNull(response);
                assertEquals(5.0, response.getRating());
                assertEquals("Great stay!", response.getComment());
                verify(reviewRepository, times(1)).save(any(Review.class));
            }
        }

        @Test
        void createReview_shouldThrowUserNotFoundException_whenUserNotLoggedIn() {
            try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder = mockStatic(SecurityContextHolder.class)) {
                mockedSecurityContextHolder.when(SecurityContextHolder::getContext).thenReturn(securityContext);
                when(securityContext.getAuthentication()).thenReturn(authentication);
                when(authentication.getPrincipal()).thenReturn("test@test.com");

                ReviewRequestDTO requestDTO = new ReviewRequestDTO();
                requestDTO.setHotelId(1L);
                requestDTO.setRating(5.0);
                requestDTO.setComment("Comment");

                when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.empty());

                assertThrows(UserNotFoundException.class, () -> reviewService.createReview(requestDTO));

                verify(userRepository, times(1)).findByEmail("test@test.com");
                verify(reviewRepository, never()).save(any(Review.class));
            }
        }

        @Test
        void createReview_shouldThrowHotelNotFoundException_whenHotelNotFound() {
            try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder = mockStatic(SecurityContextHolder.class)) {
                mockedSecurityContextHolder.when(SecurityContextHolder::getContext).thenReturn(securityContext);
                when(securityContext.getAuthentication()).thenReturn(authentication);
                when(authentication.getPrincipal()).thenReturn("test@test.com");

                User user = new User();
                user.setUserId(1L);
                user.setEmail("test@test.com");

                ReviewRequestDTO requestDTO = new ReviewRequestDTO();
                requestDTO.setHotelId(1L);
                requestDTO.setRating(5.0);
                requestDTO.setComment("Comment");

                when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.of(user));
                when(hotelRepository.findById(1L)).thenReturn(Optional.empty());

                assertThrows(HotelNotFoundException.class, () -> reviewService.createReview(requestDTO));

                verify(userRepository, times(1)).findByEmail("test@test.com");
                verify(hotelRepository, times(1)).findById(1L);
                verify(reviewRepository, never()).save(any(Review.class));
            }
        }
    }
    @Nested
    class ReviewRetrievalAndModificationTests {

        // No @BeforeEach or mocking of SecurityContextHolder here, as these tests don't need it.
        // We will create dummy User and Hotel objects directly in the test methods.

        @Test
        void getReviewsByHotel_shouldReturnReviews() {
            User user = new User();
            user.setUserId(1L);
            user.setEmail("test@test.com");

            Hotel hotel = new Hotel();
            hotel.setHotelId(1L);

            Review review = new Review();
            review.setReviewId(1L);
            review.setRating(5.0);
            review.setComment("Great stay!");
            review.setTimestamp(LocalDateTime.now());
            review.setUser(user);
            review.setHotel(hotel);

            when(reviewRepository.findByHotel_HotelId(1L)).thenReturn(List.of(review));

            List<ReviewResponseDTO> reviews = reviewService.getReviewsByHotel(1L);

            assertFalse(reviews.isEmpty());
            assertEquals(1, reviews.size());
            assertEquals("Great stay!", reviews.get(0).getComment());
            verify(reviewRepository, times(1)).findByHotel_HotelId(1L);
        }

        @Test
        void getReviewsByHotel_shouldThrowException_whenNoReviewsFound() {
            when(reviewRepository.findByHotel_HotelId(1L)).thenReturn(Collections.emptyList());

            ReviewNotFoundException exception = assertThrows(ReviewNotFoundException.class, () ->
                    reviewService.getReviewsByHotel(1L)
            );

            assertEquals("No reviews found for hotel with ID: 1", exception.getMessage());
            verify(reviewRepository, times(1)).findByHotel_HotelId(1L);
        }

        @Test
        void getReviewsByUser_shouldReturnReviews() {
            User user = new User();
            user.setUserId(1L);
            user.setEmail("test@test.com");

            Hotel hotel = new Hotel();
            hotel.setHotelId(1L);

            Review review = new Review();
            review.setReviewId(1L);
            review.setRating(5.0);
            review.setComment("Great stay!");
            review.setTimestamp(LocalDateTime.now());
            review.setUser(user);
            review.setHotel(hotel);

            when(reviewRepository.findByUser_UserId(1L)).thenReturn(List.of(review));

            List<ReviewResponseDTO> reviews = reviewService.getReviewsByUser(1L);

            assertFalse(reviews.isEmpty());
            assertEquals(1, reviews.size());
            assertEquals(5.0, reviews.get(0).getRating());
            verify(reviewRepository, times(1)).findByUser_UserId(1L);
        }

        @Test
        void getReviewsByUser_shouldThrowException_whenNoReviewsFound() {
            when(reviewRepository.findByUser_UserId(1L)).thenReturn(Collections.emptyList());

            ReviewNotFoundException exception = assertThrows(ReviewNotFoundException.class, () ->
                    reviewService.getReviewsByUser(1L)
            );

            assertEquals("No reviews found for user with ID: 1", exception.getMessage());
            verify(reviewRepository, times(1)).findByUser_UserId(1L);
        }

        @Test
        void respondToReview_shouldUpdateResponse() {
            User user = new User();
            user.setUserId(1L);
            user.setEmail("test@test.com");

            Hotel hotel = new Hotel();
            hotel.setHotelId(1L);

            Review review = new Review();
            review.setReviewId(1L);
            review.setRating(5.0);
            review.setComment("Great stay!");
            review.setTimestamp(LocalDateTime.now());
            review.setUser(user);
            review.setHotel(hotel);

            when(reviewRepository.findById(1L)).thenReturn(Optional.of(review));
            when(reviewRepository.save(any(Review.class))).thenReturn(review);

            ReviewResponseDTO response = reviewService.respondToReview(1L, "Thank you!");

            assertNotNull(response);
            assertEquals("Thank you!", response.getResponse());
            verify(reviewRepository, times(1)).findById(1L);
            verify(reviewRepository, times(1)).save(any(Review.class));
        }

        @Test
        void respondToReview_shouldThrowException_whenReviewNotFound() {
            when(reviewRepository.findById(1L)).thenReturn(Optional.empty());

            ReviewNotFoundException exception = assertThrows(ReviewNotFoundException.class, () ->
                    reviewService.respondToReview(1L, "Thank you!")
            );

            assertEquals("Review Not Found", exception.getMessage());
            verify(reviewRepository, times(1)).findById(1L);
            verify(reviewRepository, never()).save(any(Review.class));
        }

        @Test
        void updateResponse_shouldUpdateResponse() {
            User user = new User();
            user.setUserId(1L);
            user.setEmail("test@test.com");

            Hotel hotel = new Hotel();
            hotel.setHotelId(1L);

            Review review = new Review();
            review.setReviewId(1L);
            review.setRating(5.0);
            review.setComment("Great stay!");
            review.setTimestamp(LocalDateTime.now());
            review.setUser(user);
            review.setHotel(hotel);

            when(reviewRepository.findById(1L)).thenReturn(Optional.of(review));
            when(reviewRepository.save(any(Review.class))).thenReturn(review);

            ReviewResponseDTO response = reviewService.updateResponse(1L, "Updated response.");

            assertNotNull(response);
            assertEquals("Updated response.", response.getResponse());
            verify(reviewRepository, times(1)).findById(1L);
            verify(reviewRepository, times(1)).save(any(Review.class));
        }

        @Test
        void deleteReview_shouldDeleteReviewSuccessfully() {
            doNothing().when(reviewRepository).deleteById(1L);

            assertDoesNotThrow(() -> reviewService.deleteReview(1L));

            verify(reviewRepository, times(1)).deleteById(1L);
        }
    }
}
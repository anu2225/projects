package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.UserRegistrationDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.UserResponseDTO;
import com.cognizant.smarthotelbooking.entity.User;
import com.cognizant.smarthotelbooking.exception.UserNotFoundException;
import com.cognizant.smarthotelbooking.repository.UserRepository;
import com.cognizant.smarthotelbooking.service.impl.UserServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

import static com.cognizant.smarthotelbooking.entity.enums.Role.MANAGER;
import static com.cognizant.smarthotelbooking.entity.enums.Role.USER;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @InjectMocks
    private UserServiceImpl userService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    // Test for registerUser
    @Test
    void testRegisterUser() {
        // Arrange
        UserRegistrationDTO registrationDTO = new UserRegistrationDTO("John Doe", "johndoe@example.com", "password123", "1234567890");
        User user = new User(1L,"John Doe", "johndoe@example.com", "encodedPassword123", USER, "1234567890", true, null, null, null, null, null);

        when(passwordEncoder.encode(registrationDTO.getPassword())).thenReturn("encodedPassword123");
        when(userRepository.save(any(User.class))).thenReturn(user);

        // Act
        userService.registerUser(registrationDTO);

        // Assert
        verify(passwordEncoder, times(1)).encode("password123");
        verify(userRepository, times(1)).save(any(User.class));
    }

    // Test for getUserById - valid ID
    @Test
    void testGetUserById_ValidId() {
        // Arrange
        User user = new User(1L,"John Doe", "johndoe@example.com", "encodedPassword123", USER, "1234567890", true, null, null, null, null, null);
        UserResponseDTO userResponseDTO = new UserResponseDTO(1L, "John Doe", "johndoe@example.com", USER, "1234567890");

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        // Act
        UserResponseDTO result = userService.getUserById(1L);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getUserId()).isEqualTo(userResponseDTO.getUserId());
        assertThat(result.getEmail()).isEqualTo(userResponseDTO.getEmail());
    }

    // Test for getUserById - invalid ID
    @Test
    void testGetUserById_InvalidId() {
        // Arrange
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        // Assert & Act
        assertThrows(UserNotFoundException.class, () -> userService.getUserById(99L));
    }

    // Test for getAllUsers
    @Test
    void testGetAllUsers() {
        // Arrange
        User user1 = new User(1L,"John Doe", "johndoe@example.com", "encodedPassword123", USER, "1234567890", true, null, null, null, null, null);
        User user2 = new User(2L,"Jane Doe", "janedoe@example.com", "encodedPassword123", USER, "1234567890", true, null, null, null, null, null);
        List<User> userList = List.of(user1, user2);

        when(userRepository.findByRole(USER)).thenReturn(List.of(
                new UserResponseDTO(user1.getUserId(), user1.getName(), user1.getEmail(), user1.getRole(), user1.getContactNumber()),
                new UserResponseDTO(user2.getUserId(), user2.getName(), user2.getEmail(), user2.getRole(), user2.getContactNumber())
        ));

        // Act
        List<UserResponseDTO> result = userService.getAllUsers();

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(2);
        assertThat(result.get(0).getEmail()).isEqualTo("johndoe@example.com");
    }

    // Test for getAllManagers
    @Test
    void testGetAllManagers() {
        // Arrange
        User manager1 = new User(1L, "Manager One", "manager1@example.com", "pass1", MANAGER, "1112223334", true, null, null, null, null, null);
        User manager2 = new User(2L, "Manager Two", "manager2@example.com", "pass2", MANAGER, "4445556667", true, null, null, null, null,null);
        List<User> managerList = List.of(manager1, manager2);

        when(userRepository.findByRole(MANAGER)).thenReturn(List.of(
                new UserResponseDTO(manager1.getUserId(), manager1.getName(), manager1.getEmail(), manager1.getRole(), manager1.getContactNumber()),
                new UserResponseDTO(manager2.getUserId(), manager2.getName(), manager2.getEmail(), manager2.getRole(), manager2.getContactNumber())
        ));

        // Act
        List<UserResponseDTO> result = userService.getAllManagers();

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(2);
        assertThat(result.get(1).getEmail()).isEqualTo("manager2@example.com");
    }
}

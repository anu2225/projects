package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.PaymentRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.PaymentResponseDTO;
import com.cognizant.smarthotelbooking.entity.*;
import com.cognizant.smarthotelbooking.entity.enums.BookingStatus;
import com.cognizant.smarthotelbooking.entity.enums.PaymentStatus;
import com.cognizant.smarthotelbooking.exception.BookingNotFoundException;
import com.cognizant.smarthotelbooking.exception.PaymentNotFoundException;
import com.cognizant.smarthotelbooking.exception.RoomNotFoundException;
import com.cognizant.smarthotelbooking.repository.*;
        import com.cognizant.smarthotelbooking.service.impl.PaymentServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PaymentServiceTest {

    @InjectMocks
    private PaymentServiceImpl paymentService;

    @Mock
    private PaymentRepository paymentRepository;

    @Mock
    private BookingRepository bookingRepository;

    @Mock
    private RoomRepository roomRepository;

    @Mock
    private LoyaltyAccountRepository loyaltyAccountRepository;

    @Mock
    private LoyaltyTransactionRepository loyaltyTransactionRepository;

    private PaymentRequestDTO paymentRequestDTO;
    private Booking booking;
    private Room room;
    private Payment payment;
    private User user;
    private LoyaltyAccount loyaltyAccount;

    @BeforeEach
    void setUp() {
        paymentRequestDTO = new PaymentRequestDTO();
        paymentRequestDTO.setBookingId(1L);
        paymentRequestDTO.setPaymentMethod("Credit Card");

        user = new User();
        user.setUserId(1L);
        user.setEmail("testuser@example.com");

        room = new Room();
        room.setRoomId(101L);
        room.setPrice(100.0);

        booking = new Booking();
        booking.setBookingId(1L);
        booking.setRoomId(room.getRoomId());
        booking.setUser(user);
        booking.setCheckInDate(LocalDate.now().plusDays(1));
        booking.setCheckOutDate(LocalDate.now().plusDays(3));

        payment = new Payment();
        payment.setPaymentId(1L);
        payment.setBooking(booking);
        payment.setUser(user);
        payment.setAmount(200.0);
        payment.setPaymentStatus(PaymentStatus.PENDING);

        loyaltyAccount = new LoyaltyAccount();
        loyaltyAccount.setUser(user);
        loyaltyAccount.setPointsBalance(50);
    }

    @Test
    void processPayment_shouldUpdatePaymentAndBookingStatusAndRewardPoints() {
        // Arrange
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
        when(roomRepository.findById(101L)).thenReturn(Optional.of(room));
        when(paymentRepository.findByBooking_BookingId(1L)).thenReturn(payment);
        when(loyaltyAccountRepository.findByUser_UserId(user.getUserId())).thenReturn(loyaltyAccount);

        // Act
        PaymentResponseDTO result = paymentService.processPayment(paymentRequestDTO);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getPaymentStatus()).isEqualTo(PaymentStatus.SUCCESS.name());
        assertThat(booking.getStatus()).isEqualTo(BookingStatus.CONFIRMED);
        assertThat(loyaltyAccount.getPointsBalance()).isEqualTo(70); // 50 (old) + 20 (earned)
        verify(paymentRepository, times(1)).findByBooking_BookingId(1L);
        verify(loyaltyAccountRepository, times(1)).save(loyaltyAccount);
        verify(loyaltyTransactionRepository, times(1)).save(any(LoyaltyTransaction.class));
    }

    @Test
    void processPayment_shouldThrowBookingNotFoundException() {
        // Arrange
        when(bookingRepository.findById(any())).thenReturn(Optional.empty());

        // Assert & Act
        assertThrows(BookingNotFoundException.class, () -> paymentService.processPayment(paymentRequestDTO));
    }

    @Test
    void getPaymentById_shouldReturnPayment() {
        // Arrange
        when(paymentRepository.findById(1L)).thenReturn(Optional.of(payment));

        // Act
        PaymentResponseDTO result = paymentService.getPaymentById("1");

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getPaymentId()).isEqualTo(1L);
        verify(paymentRepository, times(1)).findById(1L);
    }

    @Test
    void getPaymentById_shouldThrowExceptionForInvalidId() {
        // Arrange
        when(paymentRepository.findById(99L)).thenReturn(Optional.empty());

        // Assert & Act
        assertThrows(PaymentNotFoundException.class, () -> paymentService.getPaymentById("99"));
    }

    @Test
    void getPaymentByBookingId_shouldReturnPayment() {
        // Arrange
        when(paymentRepository.findAll()).thenReturn(Collections.singletonList(payment));

        // Act
        PaymentResponseDTO result = paymentService.getPaymentByBookingId("1");

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getBookingId()).isEqualTo(1L);
        verify(paymentRepository, times(1)).findAll();
    }

    @Test
    void getPaymentByBookingId_shouldThrowExceptionForInvalidId() {
        // Arrange
        when(paymentRepository.findAll()).thenReturn(Collections.emptyList());

        // Assert & Act
        assertThrows(PaymentNotFoundException.class, () -> paymentService.getPaymentByBookingId("99"));
    }

    @Test
    void getAllPayments_shouldReturnPayments() {
        // Arrange
        Authentication authentication = mock(Authentication.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.getPrincipal()).thenReturn("testuser@example.com");

        when(paymentRepository.findPaymentsByUserEmail("testuser@example.com")).thenReturn(Collections.singletonList(payment));

        // Act
        List<Payment> result = paymentService.getAllPayments();

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(1);
        verify(paymentRepository, times(1)).findPaymentsByUserEmail("testuser@example.com");
    }

    @Test
    void getAllPayments_shouldThrowExceptionWhenNoPaymentsFound() {
        // Arrange
        Authentication authentication = mock(Authentication.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.getPrincipal()).thenReturn("testuser@example.com");

        when(paymentRepository.findPaymentsByUserEmail("testuser@example.com")).thenReturn(Collections.emptyList());

        // Assert & Act
        assertThrows(PaymentNotFoundException.class, () -> paymentService.getAllPayments());
    }
}
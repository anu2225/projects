package com.cognizant.smarthotelbooking.dto.requestdto;

import com.cognizant.smarthotelbooking.entity.enums.Role;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserRegistrationDTO {
     @NotBlank(message = "Name is required")
     private String name;

     @NotBlank(message = "Email is required")
     @Email(regexp = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}", message = "Invalid Email")
     private String email;

     @Size(min = 8, message = "Password must be at least 8 characters long")
     private String password;

     @Pattern(regexp = "^\\d{10}$", message = "Invalid Contact Number")
     private String contactNumber;

}

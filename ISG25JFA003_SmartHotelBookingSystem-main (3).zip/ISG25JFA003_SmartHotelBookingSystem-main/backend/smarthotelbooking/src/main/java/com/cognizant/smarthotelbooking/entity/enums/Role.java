package com.cognizant.smarthotelbooking.entity.enums;

public enum Role {
    ADMIN,
    MANAGER,
    USER
}
package com.cognizant.smarthotelbooking.dto.requestdto;


import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BookingRequestDTO {

    @NotNull(message = "Room Id is required")
    private Long roomId;
    @NotNull(message = "CheckInDate is required")
    private LocalDate checkInDate;
    @NotNull(message = "CheckOutDate is required")
    private LocalDate checkOutDate;
    @AssertTrue(message = "Check-out date must be after check-in date.")
    public boolean isCheckOutAfterCheckIn() {
        if (checkInDate == null || checkOutDate == null) {
            return true;
        }
        return checkOutDate.isAfter(checkInDate);
    }
}
package com.cognizant.smarthotelbooking.entity.enums;

public enum PaymentStatus {
    SUCCESS,
    PENDING,
    FAILED
}

package com.cognizant.smarthotelbooking.exception;

public class BookingCancelException extends RuntimeException {
    public BookingCancelException(String message) {
        super(message);
    }
}

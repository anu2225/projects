package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.BookingRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.BookingResponseDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.BookingRoomResponseDTO;

import java.util.List;

public interface BookingService {

    BookingResponseDTO createBooking(BookingRequestDTO bookingRequest);

    BookingRoomResponseDTO getBookingById(long bookingId);

    List<BookingResponseDTO> getBookingsByUserId(long userId);

    void updateBooking(String bookingId, BookingRequestDTO updatedBooking);

    void cancelBooking(String bookingId);

    List<BookingResponseDTO> getAllBookings();

//    List<BookingResponseDTO> getBookingsByHotel(long hotelId);
}
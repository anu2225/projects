package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.UserRegistrationDTO;
import jakarta.validation.Valid;

public interface AdminService {
    void createManager(@Valid UserRegistrationDTO request);

}

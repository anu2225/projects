package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.requestdto.ReviewRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.ReviewResponseDTO;
import com.cognizant.smarthotelbooking.service.ReviewService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
@Slf4j
public class ReviewController {

    private final ReviewService reviewService;

    // User Action: Submit a review (requires booking verification)
    @PreAuthorize("hasRole('USER')")
    @PostMapping
    public ResponseEntity<ReviewResponseDTO> submitReview(@RequestBody ReviewRequestDTO dto) {
        return ResponseEntity.ok(reviewService.createReview(dto));
    }

    // User Action: Get all reviews for a specific hotel
    @GetMapping("/hotel/{hotelId}")
    public ResponseEntity<List<ReviewResponseDTO>> getReviewsByHotel(@PathVariable Long hotelId) {
        log.info("Getting reviews of Hotel with hotelId {}", hotelId);
        return ResponseEntity.ok(reviewService.getReviewsByHotel(hotelId));
    }

    // User Action: Get all reviews submitted by a specific user
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<ReviewResponseDTO>> getReviewsByUser(@PathVariable Long userId) {
        log.info("Getting reviews of User with userid {}", userId);
        return ResponseEntity.ok(reviewService.getReviewsByUser(userId));
    }

    // Hotel Manager Action: Respond to a review
    @PreAuthorize("hasRole('MANAGER')")
    @PostMapping("/{reviewId}/response")
    public ResponseEntity<ReviewResponseDTO> respondToReview(@PathVariable Long reviewId, @RequestBody String response) {
        return ResponseEntity.ok(reviewService.respondToReview(reviewId, response));
    }

    // Hotel Manager Action: Update a previously submitted response
    @PutMapping("/{reviewId}/response")
    public ResponseEntity<ReviewResponseDTO> updateResponse(@PathVariable Long reviewId, @RequestBody String response) {
        return ResponseEntity.ok(reviewService.updateResponse(reviewId, response));
    }

    // Hotel Manager Action: Delete inappropriate or flagged reviews
    @PreAuthorize("hasRole('MANAGER')")
    @DeleteMapping("/{reviewId}")
    public ResponseEntity<String> deleteReview(@PathVariable Long reviewId) {
        reviewService.deleteReview(reviewId);
        return ResponseEntity.ok("Review deleted successfully");
    }
}

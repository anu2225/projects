package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.PaymentRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.PaymentResponseDTO;
import com.cognizant.smarthotelbooking.entity.Payment;

import java.util.List;

public interface PaymentService {

    PaymentResponseDTO processPayment(PaymentRequestDTO paymentRequest);

    PaymentResponseDTO getPaymentById(String paymentId);

    PaymentResponseDTO getPaymentByBookingId(String bookingId);

    List<Payment> getAllPayments();
}
package com.cognizant.smarthotelbooking.service.impl;

import com.cognizant.smarthotelbooking.dto.requestdto.UserRegistrationDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.UserResponseDTO;
import com.cognizant.smarthotelbooking.entity.User;
import com.cognizant.smarthotelbooking.entity.enums.Role;
import com.cognizant.smarthotelbooking.exception.UserNotFoundException;
import com.cognizant.smarthotelbooking.repository.UserRepository;
import com.cognizant.smarthotelbooking.service.UserService;
import com.cognizant.smarthotelbooking.util.UserInfoDetails;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.cognizant.smarthotelbooking.entity.enums.Role.MANAGER;
import static com.cognizant.smarthotelbooking.entity.enums.Role.USER;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService, UserDetailsService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
           User user = userRepository.findByEmail(username)
                       .orElseThrow(() -> new UsernameNotFoundException("User not found " + username));

           if(!user.isActive() && user.getRole() != Role.ADMIN) {
               throw new BadCredentialsException("Account is inactive");
           }

           return new UserInfoDetails(user);
    }


    @Override
    public void registerUser(@Valid UserRegistrationDTO request) {
        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(USER);
        user.setContactNumber(request.getContactNumber());


        userRepository.save(user);
    }

    @Override
    public UserResponseDTO getUserById(long id) {
        User user = userRepository.findById(id).orElseThrow(() -> new UserNotFoundException("User not found"));
        return mapToDTO(user);
    }

    @Override
    public List<UserResponseDTO> getAllUsers() {
        List<UserResponseDTO> users = userRepository.findByRole(USER);
        if(users.isEmpty()) {
            throw new UserNotFoundException("No Users found");
        }
        return users;
    }

    @Override
    public List<UserResponseDTO> getAllManagers() {
        List<UserResponseDTO> managers = userRepository.findByRole(MANAGER);
        if(managers.isEmpty()) {
            throw new UserNotFoundException("No Managers found");
        }
        return managers;
    }

    private UserResponseDTO mapToDTO(User user) {
        return new UserResponseDTO(
                user.getUserId(),
                user.getName(),
                user.getEmail(),
                user.getRole(),
                user.getContactNumber()
        );
    }
}

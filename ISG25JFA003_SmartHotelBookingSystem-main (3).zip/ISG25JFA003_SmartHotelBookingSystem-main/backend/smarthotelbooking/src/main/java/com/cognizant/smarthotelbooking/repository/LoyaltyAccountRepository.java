package com.cognizant.smarthotelbooking.repository;

import com.cognizant.smarthotelbooking.entity.LoyaltyAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoyaltyAccountRepository extends JpaRepository<LoyaltyAccount, Long> {
    LoyaltyAccount findByUser_UserId(Long userId);
}

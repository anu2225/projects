package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.requestdto.BookingRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.BookingResponseDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.BookingRoomResponseDTO;
import com.cognizant.smarthotelbooking.entity.Booking;
import com.cognizant.smarthotelbooking.service.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
@Slf4j
public class BookingController {

    private final BookingService bookingService;

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/create")
    public ResponseEntity<BookingResponseDTO> createBooking(@Valid @RequestBody BookingRequestDTO bookingRequest) {
        log.info("Creating Booking...");
        BookingResponseDTO booking = bookingService.createBooking(bookingRequest);
        return ResponseEntity.ok(booking);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public ResponseEntity<List<BookingResponseDTO>> getAllBookings() {
        log.info("Getting all bookings");
        List<BookingResponseDTO> booking =  bookingService.getAllBookings();
        return ResponseEntity.ok(booking);
    }

    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    @GetMapping("/{bookingId}")
    public ResponseEntity<BookingRoomResponseDTO> getBooking(@PathVariable long bookingId) {
        log.info("Fetching booking with ID: {}", bookingId);
        BookingRoomResponseDTO booking = bookingService.getBookingById(bookingId);
        return ResponseEntity.ok(booking);
    }

    @PreAuthorize("hasAnyRole('ADMIN','USER','MANAGER')")
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BookingResponseDTO>> getBookingsByUser(@PathVariable long userId) {
        log.info("Fetching all bookings for user ID: {}", userId);
        List<BookingResponseDTO> bookings = bookingService.getBookingsByUserId(userId);
        return ResponseEntity.ok(bookings);
    }

    @PutMapping("/{bookingId}") // I dont think it is needed
    public ResponseEntity<String> updateBooking(@PathVariable String bookingId,
                                                @Valid @RequestBody BookingRequestDTO updatedBooking) {
        log.info("Updating booking ID: {}", bookingId);
        bookingService.updateBooking(bookingId, updatedBooking);
        return ResponseEntity.ok("Booking updated successfully.");
    }

    @PreAuthorize("hasRole('USER')")
    @DeleteMapping("/{bookingId}")
    public ResponseEntity<String> cancelBooking(@PathVariable String bookingId) {
        log.info("Cancelling booking ID: {}", bookingId);
        bookingService.cancelBooking(bookingId);
        return ResponseEntity.ok("Booking cancelled successfully.");
    }
}

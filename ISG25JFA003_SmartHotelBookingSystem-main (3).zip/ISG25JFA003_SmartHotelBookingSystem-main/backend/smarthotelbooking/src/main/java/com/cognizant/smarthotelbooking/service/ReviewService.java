package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.ReviewRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.ReviewResponseDTO;

import java.util.List;

public interface ReviewService {
    ReviewResponseDTO createReview(ReviewRequestDTO dto);
    List<ReviewResponseDTO> getReviewsByHotel(Long hotelId);
    List<ReviewResponseDTO> getReviewsByUser(Long userId);
    ReviewResponseDTO respondToReview(Long reviewId, String response);
    ReviewResponseDTO updateResponse(Long reviewId, String response);
    void deleteReview(Long reviewId);
}

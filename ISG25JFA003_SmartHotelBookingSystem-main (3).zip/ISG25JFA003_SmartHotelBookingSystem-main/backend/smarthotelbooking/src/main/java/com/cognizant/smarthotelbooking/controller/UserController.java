package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.responsedto.UserResponseDTO;
import com.cognizant.smarthotelbooking.service.impl.UserServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/user")
@Slf4j
public class UserController {

    private final UserServiceImpl userService;


    @GetMapping("/welcome-user")
    public String welcomeUser() {
        return "Welcome to protected route";
    }

    @PreAuthorize("hasAnyRole('ADMIN','USER','MANAGER')")
    @GetMapping("/{id}")
    public ResponseEntity<UserResponseDTO> getUserById(@PathVariable int id) {
        log.info("Getting user by ID {}",id);
        return ResponseEntity.ok(userService.getUserById(id));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/users")
    public ResponseEntity<List<UserResponseDTO>> getAllUsers() {
        log.info("Getting all users");
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/managers")
    public ResponseEntity<List<UserResponseDTO>> getAllManagers() {
        log.info("Getting all managers");
        return ResponseEntity.ok(userService.getAllManagers());
    }

}

package com.cognizant.smarthotelbooking.controller;

public class UserControllerTest {
}

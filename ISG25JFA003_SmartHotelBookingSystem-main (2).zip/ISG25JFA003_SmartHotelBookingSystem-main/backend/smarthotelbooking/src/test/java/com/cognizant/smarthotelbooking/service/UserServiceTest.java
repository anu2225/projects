package com.cognizant.smarthotelbooking.service;

public class UserServiceTest {

}

package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.requestdto.RoomRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.RoomResponseDTO;
import com.cognizant.smarthotelbooking.service.RoomService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
@Slf4j
public class RoomController {

    private final RoomService roomService;

    @PostMapping
    public RoomResponseDTO createRoom(@RequestBody RoomRequestDTO roomRequestDTO) {
        return roomService.createRoom(roomRequestDTO);
    }

    @PutMapping("/{id}")
    public RoomResponseDTO updateRoom(@PathVariable Long id, @RequestBody RoomRequestDTO roomRequestDTO) {
        return roomService.updateRoom(id, roomRequestDTO);
    }

    @DeleteMapping("/{id}")
    public void deleteRoom(@PathVariable Long id) {
        roomService.deleteRoom(id);
    }

    @GetMapping("/{id}")
    public RoomResponseDTO getRoomById(@PathVariable Long id) {
        log.info("Getting room with roomId {} ", id);
        return roomService.getRoomById(id);
    }

    @GetMapping
    public List<RoomResponseDTO> getAllRooms() {
        log.info("Getting all rooms");
        return roomService.getAllRooms();
    }

    @GetMapping("/hotel/{hotelId}")
    public List<RoomResponseDTO> getRoomsByHotel(@PathVariable Long hotelId) {
        log.info("Getting rooms from Hotel with hotelId {}", hotelId);
        return roomService.getRoomsByHotel(hotelId);
    }

    @GetMapping("/filter")
    public List<RoomResponseDTO> filterByPrice(@RequestParam Double min, @RequestParam Double max) {
        return roomService.filterByPrice(min, max);
    }

    @GetMapping("/available")
    public List<RoomResponseDTO> getAvailableRooms() {
        log.info("Getting available rooms");
        return roomService.getAvailableRooms();
    }
}
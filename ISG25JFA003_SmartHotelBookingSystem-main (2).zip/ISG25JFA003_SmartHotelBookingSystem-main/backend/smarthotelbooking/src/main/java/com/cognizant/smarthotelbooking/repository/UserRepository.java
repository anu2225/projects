package com.cognizant.smarthotelbooking.repository;

import com.cognizant.smarthotelbooking.dto.responsedto.UserResponseDTO;
import com.cognizant.smarthotelbooking.entity.User;
import com.cognizant.smarthotelbooking.entity.enums.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User,Long> {
    boolean existsByEmail(String email);

    Optional<User> findByEmail(String username);

    List<UserResponseDTO> findByRole(Role role);
}

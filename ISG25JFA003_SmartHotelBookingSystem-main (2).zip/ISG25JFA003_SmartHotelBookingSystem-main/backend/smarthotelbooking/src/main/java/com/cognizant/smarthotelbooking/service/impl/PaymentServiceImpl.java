package com.cognizant.smarthotelbooking.service.impl;

import com.cognizant.smarthotelbooking.dto.requestdto.PaymentRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.PaymentResponseDTO;
import com.cognizant.smarthotelbooking.entity.*;
import com.cognizant.smarthotelbooking.repository.*;
import com.cognizant.smarthotelbooking.entity.enums.Action;
import com.cognizant.smarthotelbooking.entity.enums.BookingStatus;
import com.cognizant.smarthotelbooking.entity.enums.PaymentStatus;
import com.cognizant.smarthotelbooking.exception.BookingNotFoundException;
import com.cognizant.smarthotelbooking.exception.PaymentNotFoundException;
import com.cognizant.smarthotelbooking.exception.RoomNotFoundException;
import com.cognizant.smarthotelbooking.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final BookingRepository bookingRepository;
    private final RoomRepository roomRepository;
    private final LoyaltyAccountRepository loyaltyAccountRepository;
    private final LoyaltyTransactionRepository loyaltyTransactionRepository;

    @Override
    public PaymentResponseDTO processPayment(PaymentRequestDTO dto) {
        Booking booking = bookingRepository.findById(dto.getBookingId())
                .orElseThrow(() -> new BookingNotFoundException("Booking not found"));

        Room room = roomRepository.findById(booking.getRoomId())
                .orElseThrow(() -> new RoomNotFoundException("Room not found"));

        Payment payment = paymentRepository.findByBooking_BookingId(dto.getBookingId());
        if(payment == null) {
            throw new PaymentNotFoundException("Payment Request Not Found");
        }
        payment.setPaymentMethod(dto.getPaymentMethod());
        payment.setPaymentStatus(PaymentStatus.Success);
        booking.setStatus(BookingStatus.Confirmed);
        bookingRepository.save(booking);



        double price = room.getPrice();
        LocalDate checkInDate = booking.getCheckInDate();
        LocalDate checkOutDate = booking.getCheckOutDate();
        double finalPrice = price * checkInDate.until(checkOutDate, ChronoUnit.DAYS);

        int earnedPoints = (int) (finalPrice / 10);
        LoyaltyAccount account = loyaltyAccountRepository.findByUser_UserId(booking.getUser().getUserId());

        if (account == null) {
            account = new LoyaltyAccount();
            account.setUser(booking.getUser());
            account.setPointsBalance(earnedPoints);
            account.setLastUpdated(LocalDateTime.now());
        } else {
            account.setPointsBalance(account.getPointsBalance() + earnedPoints);
            account.setLastUpdated(LocalDateTime.now());
        }

        loyaltyAccountRepository.save(account);

        LoyaltyTransaction transaction = new LoyaltyTransaction(null, booking.getUser(), Action.EARN,
                "Earned points from payment", earnedPoints, LocalDateTime.now());
        loyaltyTransactionRepository.save(transaction);

        return mapToDTO(payment);
    }


    @Override
    public PaymentResponseDTO getPaymentById(String paymentId) {
        Payment payment = paymentRepository.findById(Long.parseLong(paymentId))
                .orElseThrow(() -> new PaymentNotFoundException("Payment not found"));
        return mapToDTO(payment);
    }

    @Override
    public PaymentResponseDTO getPaymentByBookingId(String bookingId) {
        Long bookingIdLong = Long.parseLong(bookingId);
        return paymentRepository.findAll().stream()
                .filter(p -> p.getBooking().getBookingId().equals(bookingIdLong))
                .findFirst()
                .map(this::mapToDTO)
                .orElseThrow(() -> new PaymentNotFoundException("Payment not found for booking"));
    }

    @Override
    public List<Payment> getAllPayments() {
        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
        List<Payment> payments = paymentRepository.findPaymentsByUserEmail(email);

        if (payments.isEmpty()) {
            throw new PaymentNotFoundException("No payments found for the current user with email: " + email);
        }

        return payments;
    }

    private PaymentResponseDTO mapToDTO(Payment payment) {
        PaymentResponseDTO dto = new PaymentResponseDTO();
        dto.setPaymentId(payment.getPaymentId());
        dto.setBookingId(payment.getBooking().getBookingId());
        dto.setAmount(payment.getAmount());
        dto.setPaymentDate(LocalDate.now());
        dto.setPaymentMethod(payment.getPaymentMethod());
        dto.setPaymentStatus(payment.getPaymentStatus().name());
        return dto;
    }
}
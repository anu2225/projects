package com.cognizant.smarthotelbooking.controller;

import com.cognizant.smarthotelbooking.dto.requestdto.UserRegistrationDTO;
import com.cognizant.smarthotelbooking.service.impl.AdminServiceImpl;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


@RequestMapping("/api/admin")
@RequiredArgsConstructor
@RestController
public class AdminController {

    private final AdminServiceImpl adminService;

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/create-manager-account")
//    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> createManager(@Valid @RequestBody UserRegistrationDTO request) {
        adminService.createManager(request);
        return ResponseEntity.ok("Hotel Manager account created successfully!");
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PatchMapping("/user/{id}/status")
    public ResponseEntity<String> updateManagerStatus(@PathVariable int id, @RequestBody Map<String, Boolean> body) {
        boolean newStatus = body.get("active");
        adminService.updateUserStatus(Math.toIntExact(id), newStatus);
        return ResponseEntity.ok("Changed Manager Status");
    }

}

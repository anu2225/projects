package com.cognizant.smarthotelbooking.service;

import com.cognizant.smarthotelbooking.dto.requestdto.UserRegistrationDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.UserResponseDTO;
import jakarta.validation.Valid;

import java.util.List;

public interface UserService {

    void registerUser(@Valid UserRegistrationDTO user);

    UserResponseDTO getUserById(long id);

    List<UserResponseDTO> getAllUsers();

    List<UserResponseDTO> getAllManagers();

//    List<Booking> getAllBookings();
//
//    List<Payment> getAllPayments();
}

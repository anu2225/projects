package com.cognizant.smarthotelbooking.service.impl;

import com.cognizant.smarthotelbooking.dto.requestdto.BookingRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.BookingResponseDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.BookingRoomResponseDTO;
import com.cognizant.smarthotelbooking.entity.Booking;
import com.cognizant.smarthotelbooking.entity.Payment;
import com.cognizant.smarthotelbooking.entity.Room;
import com.cognizant.smarthotelbooking.entity.User;
import com.cognizant.smarthotelbooking.repository.*;
import com.cognizant.smarthotelbooking.entity.enums.BookingStatus;
import com.cognizant.smarthotelbooking.entity.enums.PaymentStatus;
import com.cognizant.smarthotelbooking.exception.BookingNotFoundException;
import com.cognizant.smarthotelbooking.exception.RoomNotFoundException;
import com.cognizant.smarthotelbooking.exception.UserNotFoundException;
import com.cognizant.smarthotelbooking.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final HotelRepository hotelRepository;
    private final RoomRepository roomRepository;
    private final PaymentRepository paymentRepository;


    @Override
    public BookingResponseDTO createBooking(BookingRequestDTO dto) {
        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
        User user = userRepository.findByEmail(email).get();

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setRoomId(dto.getRoomId());
        booking.setCheckInDate(dto.getCheckInDate());
        booking.setCheckOutDate(dto.getCheckOutDate());
        booking.setBookingDate(LocalDate.now());
        booking.setStatus(BookingStatus.Pending);
        bookingRepository.save(booking);

        Room room = roomRepository.findById(dto.getRoomId())
                .orElseThrow(() -> new RoomNotFoundException("Room not found"));

        double price = room.getPrice();
        LocalDate checkInDate = booking.getCheckInDate();
        LocalDate checkOutDate = booking.getCheckOutDate();
        double finalPrice = price * checkInDate.until(checkOutDate, ChronoUnit.DAYS);

        Payment payment = new Payment();
        payment.setBooking(booking);
        payment.setUser(booking.getUser());
        payment.setAmount(finalPrice);
        payment.setPaymentDate(LocalDate.now());
        payment.setPaymentStatus(PaymentStatus.Pending);
        paymentRepository.save(payment);

        return mapToDTO(booking);
    }

    @Override
    public BookingRoomResponseDTO getBookingById(long bookingId) {
        BookingRoomResponseDTO booking = bookingRepository.findBookingDetailsById(bookingId);
        if(booking == null) {
            throw new BookingNotFoundException("Booking not found");
        }
        return booking;
    }

    @Override
    public List<BookingResponseDTO> getBookingsByUserId(long userId) {  //This function is not working correctly and not checked below other methods
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));

        // Find bookings for the user
        List<BookingResponseDTO> bookings = bookingRepository.findByUser(user);

        // Check if the list of bookings is empty
        if (bookings.isEmpty()) {
            throw new BookingNotFoundException("No bookings found for user with ID: " + userId);
        }

        // Map the entities to DTOs and return
        return bookings.stream()
                .collect(Collectors.toList());
    }

    @Override
    public void updateBooking(String bookingId, BookingRequestDTO dto) {
        Booking booking = bookingRepository.findById(Long.parseLong(bookingId))
                .orElseThrow(() -> new BookingNotFoundException("Booking not found"));

        booking.setCheckInDate(dto.getCheckInDate());
        booking.setCheckOutDate(dto.getCheckOutDate());
        booking.setBookingDate(dto.getBookingDate());
        booking.setStatus(BookingStatus.Pending);

        bookingRepository.save(booking);
    }

    @Override
    public void cancelBooking(String bookingId) {
        Booking booking = bookingRepository.findById(Long.parseLong(bookingId))
                .orElseThrow(() -> new BookingNotFoundException("Booking not found"));

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime bookingTime = booking.getBookingDate().atStartOfDay();

        // Check if more than 24 hours have passed since booking
        if (Duration.between(bookingTime, now).toHours() > 24) {
            throw new RuntimeException("You can only cancel your booking within 24 hours of booking.");
        }

        bookingRepository.deleteById(Long.parseLong(bookingId));
    }

    @Override
    public List<BookingResponseDTO> getAllBookings() {
       return bookingRepository.findAll().stream().map(this::mapToDTO)
                .collect(Collectors.toList());
    }

//    @Override
//    public List<BookingResponseDTO> getBookingsByHotel(long hotelId) {
//        Hotel hotel = hotelRepository.findById(hotelId)
//                .orElseThrow(() -> new HotelNotFoundException("Hotel not found"));
//
//
//        List<BookingResponseDTO> bookings = bookingRepository.findByHotel(hotel);
//
//        if (bookings.isEmpty()) {
//            throw new BookingNotFoundException("No bookings found for hotel with ID: " + hotelId);
//        }
//
//        // Map the entities to DTOs and return
//        return bookings.stream()
//                .collect(Collectors.toList());
//    }

    private BookingResponseDTO mapToDTO(Booking booking) {
        BookingResponseDTO dto = new BookingResponseDTO();
        dto.setBookingId(booking.getBookingId());
        dto.setUserId(booking.getUser().getUserId());
        dto.setRoomId(booking.getRoomId());
        dto.setCheckInDate(booking.getCheckInDate());
        dto.setCheckOutDate(booking.getCheckOutDate());
            if(booking.getPayment() != null) {
                dto.setPaymentAmount(booking.getPayment().getAmount());
            }
        dto.setBookingDate(booking.getBookingDate());
        dto.setStatus(booking.getStatus());
        return dto;
    }
}
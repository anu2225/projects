package com.cognizant.smarthotelbooking.dto.requestdto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class PaymentRequestDTO {
    @NotNull(message = "Booking Id is required")
    private Long bookingId;
    private Double amount;
    private LocalDate paymentDate;
    @NotBlank(message = "Payment Method should not be blank")
    private String paymentMethod;
    private String paymentStatus;
}

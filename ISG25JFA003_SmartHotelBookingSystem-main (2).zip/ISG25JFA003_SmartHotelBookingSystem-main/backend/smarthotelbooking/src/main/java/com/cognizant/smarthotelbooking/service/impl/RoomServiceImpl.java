package com.cognizant.smarthotelbooking.service.impl;

import com.cognizant.smarthotelbooking.dto.requestdto.RoomRequestDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.RoomResponseDTO;
import com.cognizant.smarthotelbooking.entity.Hotel;
import com.cognizant.smarthotelbooking.entity.Room;
import com.cognizant.smarthotelbooking.exception.HotelNotFoundException;
import com.cognizant.smarthotelbooking.exception.RoomNotFoundException;
import com.cognizant.smarthotelbooking.repository.HotelRepository;
import com.cognizant.smarthotelbooking.repository.RoomRepository;
import com.cognizant.smarthotelbooking.service.RoomService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RoomServiceImpl implements RoomService {

    private final RoomRepository roomRepository;
    private final HotelRepository hotelRepository;

    @Override
    public RoomResponseDTO createRoom(RoomRequestDTO roomRequestDTO) {
        Hotel hotel = hotelRepository.findById(roomRequestDTO.getHotelId())
                .orElseThrow(() -> new RuntimeException("Hotel not found"));

        Room room = new Room();
        room.setType(roomRequestDTO.getType());
        room.setPrice(roomRequestDTO.getPrice());
        room.setAvailability(roomRequestDTO.isAvailability());
        room.setFeatures(roomRequestDTO.getFeatures());
        room.setHotel(hotel);

        Room saved = roomRepository.save(room);
        return mapToDTO(saved);
    }

    @Override
    public RoomResponseDTO updateRoom(Long roomId, RoomRequestDTO roomRequestDTO) {
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new RoomNotFoundException("Room not found"));

        room.setType(roomRequestDTO.getType());
        room.setPrice(roomRequestDTO.getPrice());
        room.setAvailability(roomRequestDTO.isAvailability());
        room.setFeatures(roomRequestDTO.getFeatures());

        if (roomRequestDTO.getHotelId() != null) {
            Hotel hotel = hotelRepository.findById(roomRequestDTO.getHotelId())
                    .orElseThrow(() -> new HotelNotFoundException("Hotel not found"));
            room.setHotel(hotel);
        }

        Room updated = roomRepository.save(room);
        return mapToDTO(updated);
    }

    @Override
    public void deleteRoom(Long roomId) {
        roomRepository.deleteById(roomId);
    }

    @Override
    public RoomResponseDTO getRoomById(Long roomId) {
        return roomRepository.findById(roomId)
                .map(this::mapToDTO)
                .orElseThrow(() -> new RoomNotFoundException("Room not found"));
    }

    @Override
    public List<RoomResponseDTO> getAllRooms() {
        return roomRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<RoomResponseDTO> getRoomsByHotel(Long hotelId) {
        hotelRepository.findById(hotelId)
                .orElseThrow(() -> new HotelNotFoundException("Hotel not found with ID: " + hotelId));

        // 2. Find rooms for the existing hotel
        List<Room> rooms = roomRepository.findByHotel_HotelId(hotelId);

        // 3. Check if rooms were found
        if (rooms.isEmpty()) {
            throw new RoomNotFoundException("No rooms found for hotel with ID: " + hotelId);
        }

        return rooms.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<RoomResponseDTO> filterByPrice(Double min, Double max) {
        List<Room> rooms = roomRepository.findByPriceBetween(min, max);

        // Check if any rooms were found within the price range
        if (rooms.isEmpty()) {
            throw new RoomNotFoundException("No rooms found with price between " + min + " and " + max);
        }

        return rooms.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<RoomResponseDTO> getAvailableRooms() {
        List<Room> rooms = roomRepository.findByAvailabilityTrue();

        // Check if any available rooms were found
        if (rooms.isEmpty()) {
            throw new RoomNotFoundException("No available rooms found.");
        }

        return rooms.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    private RoomResponseDTO mapToDTO(Room room) {
        return new RoomResponseDTO(
                room.getRoomId(),
                room.getType(),
                room.getPrice(),
                room.isAvailability(),
                room.getFeatures(),
                room.getHotel().getHotelId()
        );
    }
}

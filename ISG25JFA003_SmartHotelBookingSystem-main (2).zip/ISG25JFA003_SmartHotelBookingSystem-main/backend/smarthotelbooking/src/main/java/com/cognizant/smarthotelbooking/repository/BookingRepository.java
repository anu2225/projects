package com.cognizant.smarthotelbooking.repository;


import com.cognizant.smarthotelbooking.dto.responsedto.BookingResponseDTO;
import com.cognizant.smarthotelbooking.dto.responsedto.BookingRoomResponseDTO;
import com.cognizant.smarthotelbooking.entity.Booking;
import com.cognizant.smarthotelbooking.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    @Query("SELECT b FROM Booking b JOIN b.user u WHERE u.email = :email")
    List<Booking> findBookingsByUserEmail(String email);

@Query("SELECT NEW com.cognizant.smarthotelbooking.dto.responsedto.BookingRoomResponseDTO(" +
        "b.bookingId, " +
        "b.user.userId, " +
        "b.user.name, " +
        "b.roomId, " +
        "r.type, " +
        "b.checkInDate, " +
        "b.checkOutDate, " +
        "b.bookingDate, " +
        "b.status) " +
        "FROM Booking b " +
        "JOIN b.user u " +
        "JOIN Room r ON b.roomId = r.roomId " +
        "WHERE b.bookingId = :bookingId")
    BookingRoomResponseDTO findBookingDetailsById(@Param("bookingId") long bookingId);

    @Query("SELECT new com.cognizant.smarthotelbooking.dto.responsedto.BookingResponseDTO(" +
            "b.bookingId, " +
            "b.user.userId, " +
            "b.roomId, " +
            "b.checkInDate, " +
            "b.checkOutDate, " +
            "b.bookingDate, " +
            "p.amount, " +
            "b.status) " +
            "FROM Booking b JOIN b.user u JOIN b.payment p " +
            "WHERE u = :user")
    List<BookingResponseDTO> findByUser(@Param("user") User user);


//    @Query("SELECT new com.smartHotelBooking.smartHotelBooking.dto.responsedto.BookingResponseDTO(" +
//            "b.bookingId, " +
//            "b.user.userId, " +
//            "b.roomId, " +
//            "b.checkInDate, " +
//            "b.checkOutDate, " +
//            "b.bookingDate, " +
//            "p.amount, " +
//            "b.status) " +
//            "FROM Booking b JOIN b.hotel u JOIN b.payment p " +
//            "WHERE h = :hotel")
//    List<BookingResponseDTO> findByHotel(@Param("hotel") Hotel hotel);
}

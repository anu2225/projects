package com.cognizant.smarthotelbooking.entity.enums;

public enum BookingStatus {
    Pending,
    Confirmed
}

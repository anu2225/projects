package com.smartHotelBooking.smartHotelBooking.repository;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.BookingRoomResponseDTO;

import com.smartHotelBooking.smartHotelBooking.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    @Query("SELECT b FROM Booking b JOIN b.user u WHERE u.email = :email")
    List<Booking> findBookingsByUserEmail(String email);

//    @Query("SELECT new BookingRoomResponseDTO(" +
//            "b.bookingId, u.userId, u.name, b.roomId, r.roomType, " +
//            "b.checkInDate, b.checkOutDate, b.bookingDate, b.status) " +
//            "FROM Booking b JOIN User u ON b.user.id = u.id " +
//            "JOIN Room r ON b.roomId = r.id " +
//            "WHERE b.bookingId = :bookingId")
//@Query(value = "SELECT " +
//        "b.booking_id AS bookingId, " +
//        "u.user_id AS userId, " +
//        "u.name AS name, " +
//        "r.room_id AS roomId, " +
//        "r.type AS roomType, " +
//        "b.check_in_date AS checkInDate, " +
//        "b.check_out_date AS checkOutDate, " +
//        "b.booking_date AS bookingDate, " +
//        "b.status AS status " +
//        "FROM booking b " +
//        "JOIN user u ON b.user_id = u.user_id " +
//        "JOIN rooms r ON b.room_id = r.room_id " +
//        "WHERE b.booking_id = :bookingId",
//        nativeQuery = true)
@Query("SELECT NEW com.smartHotelBooking.smartHotelBooking.dto.responsedto.BookingRoomResponseDTO(" +
        "b.bookingId, " +
        "b.user.userId, " +
        "b.user.name, " +
        "b.roomId, " +
        "r.type, " +
        "b.checkInDate, " +
        "b.checkOutDate, " +
        "b.bookingDate, " +
        "b.status) " +
        "FROM Booking b " +
        "JOIN b.user u " +
        "JOIN Room r ON b.roomId = r.roomId " +
        "WHERE b.bookingId = :bookingId")
    BookingRoomResponseDTO findBookingDetailsById(@Param("bookingId") long bookingId);
}

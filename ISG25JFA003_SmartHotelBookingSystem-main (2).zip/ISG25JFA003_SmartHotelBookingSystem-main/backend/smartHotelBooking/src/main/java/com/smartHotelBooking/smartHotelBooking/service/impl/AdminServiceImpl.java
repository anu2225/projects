package com.smartHotelBooking.smartHotelBooking.service.impl;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.UserRegistrationDTO;
import com.smartHotelBooking.smartHotelBooking.entity.User;
import com.smartHotelBooking.smartHotelBooking.entity.enums.Role;
import com.smartHotelBooking.smartHotelBooking.repository.UserRepository;
import com.smartHotelBooking.smartHotelBooking.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void createManager(UserRegistrationDTO request) {
        User manager = new User();
        manager.setName(request.getName());
        manager.setEmail(request.getEmail());
        manager.setPassword(passwordEncoder.encode(request.getPassword()));
        manager.setRole(Role.MANAGER);
        manager.setContactNumber(request.getContactNumber());

        userRepository.save(manager);
    }

    @Override
    public void updateUserStatus(int id, boolean newStatus) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        user.setActive(newStatus);
        userRepository.save(user);

        String action = newStatus ? "activated" : "deactivated";
    }
}

package com.smartHotelBooking.smartHotelBooking.service;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.UserRegistrationDTO;
import jakarta.validation.Valid;

public interface AdminService {
    void createManager(@Valid UserRegistrationDTO request);

    void updateUserStatus(int id, boolean newStatus);
}

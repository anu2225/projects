package com.smartHotelBooking.smartHotelBooking.service;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.LoyaltyRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.LoyaltyResponseDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.LoyaltyTransactionDTO;

import java.util.List;

public interface LoyaltyService {
    LoyaltyResponseDTO getPointsBalance(Long userId);
    LoyaltyResponseDTO redeemPoints(LoyaltyRequestDTO requestDTO);
    List<LoyaltyTransactionDTO> getTransactionHistory(Long userId);
    LoyaltyResponseDTO earnPoints(LoyaltyRequestDTO requestDTO);
    LoyaltyResponseDTO applyPointsToBooking(LoyaltyRequestDTO requestDTO);
}

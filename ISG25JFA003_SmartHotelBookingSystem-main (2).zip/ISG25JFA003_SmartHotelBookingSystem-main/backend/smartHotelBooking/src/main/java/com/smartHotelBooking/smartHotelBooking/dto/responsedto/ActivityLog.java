package com.smartHotelBooking.smartHotelBooking.dto.responsedto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ActivityLog {
    private String message;
    private LocalDateTime timestamp;
}

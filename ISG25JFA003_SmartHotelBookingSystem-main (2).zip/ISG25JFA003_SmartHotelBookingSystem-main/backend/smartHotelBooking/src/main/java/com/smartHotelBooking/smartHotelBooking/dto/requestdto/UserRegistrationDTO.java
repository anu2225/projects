package com.smartHotelBooking.smartHotelBooking.dto.requestdto;

import com.smartHotelBooking.smartHotelBooking.entity.enums.Role;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UserRegistrationDTO {
     @NotBlank(message = "Name is required")
     private String name;

     @NotBlank(message = "Email is required")
     @Email(message = "Invalid Email")
     private String email;

     @Size(min = 8, message = "Password must be at least 8 characters long")
     private String password;

     @Pattern(regexp = "^\\d{10}$", message = "Invalid Contact Number")
     private String contactNumber;

     @Enumerated(EnumType.STRING)
     private Role role;
}

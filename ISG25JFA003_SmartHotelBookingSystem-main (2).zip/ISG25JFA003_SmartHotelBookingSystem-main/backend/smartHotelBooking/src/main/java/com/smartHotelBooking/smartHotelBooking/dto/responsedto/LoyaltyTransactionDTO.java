package com.smartHotelBooking.smartHotelBooking.dto.responsedto;

import com.smartHotelBooking.smartHotelBooking.entity.enums.Action;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class LoyaltyTransactionDTO {
    private Action action;
    private String description;
    private int points;
    private LocalDateTime timestamp;
}

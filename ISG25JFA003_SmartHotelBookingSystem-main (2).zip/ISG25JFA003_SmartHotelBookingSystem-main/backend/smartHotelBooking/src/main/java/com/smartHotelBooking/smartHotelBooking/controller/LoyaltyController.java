package com.smartHotelBooking.smartHotelBooking.controller;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.LoyaltyRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.LoyaltyResponseDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.LoyaltyTransactionDTO;
import com.smartHotelBooking.smartHotelBooking.service.LoyaltyService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rewards")
@RequiredArgsConstructor
public class LoyaltyController {

    private final LoyaltyService loyaltyService;

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/{userId}")
    public LoyaltyResponseDTO getPointsBalance(@PathVariable Long userId) {
        return loyaltyService.getPointsBalance(userId);
    }

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/redeem")
    public LoyaltyResponseDTO redeemPoints(@RequestBody LoyaltyRequestDTO requestDTO) {
        return loyaltyService.redeemPoints(requestDTO);
    }

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/history/{userId}")
    public List<LoyaltyTransactionDTO> getTransactionHistory(@PathVariable Long userId) {
        return loyaltyService.getTransactionHistory(userId);
    }

    @PostMapping("/earn") //this is not needed as it is used automatically in process payment
    public LoyaltyResponseDTO earnPoints(@RequestBody LoyaltyRequestDTO requestDTO) {
        return loyaltyService.earnPoints(requestDTO);
    }

    @PostMapping("/apply") // this is also not needed
    public LoyaltyResponseDTO applyPointsToBooking(@RequestBody LoyaltyRequestDTO requestDTO) {
        return loyaltyService.applyPointsToBooking(requestDTO);
    }
}
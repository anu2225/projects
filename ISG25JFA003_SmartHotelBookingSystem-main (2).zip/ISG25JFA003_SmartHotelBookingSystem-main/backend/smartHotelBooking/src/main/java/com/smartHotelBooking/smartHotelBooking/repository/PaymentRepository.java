package com.smartHotelBooking.smartHotelBooking.repository;

import com.smartHotelBooking.smartHotelBooking.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

    @Query("SELECT p FROM Payment p JOIN p.user u WHERE u.email = :email")
    List<Payment> findPaymentsByUserEmail(String email);

    Payment findByBooking_BookingId(Long bookingId);
}

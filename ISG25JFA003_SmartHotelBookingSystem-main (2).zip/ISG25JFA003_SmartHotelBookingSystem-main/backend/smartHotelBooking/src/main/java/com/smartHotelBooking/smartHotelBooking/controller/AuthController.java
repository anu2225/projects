package com.smartHotelBooking.smartHotelBooking.controller;


import com.smartHotelBooking.smartHotelBooking.dto.requestdto.AuthRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.requestdto.UserRegistrationDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.AuthResponseDTO;
import com.smartHotelBooking.smartHotelBooking.entity.User;
import com.smartHotelBooking.smartHotelBooking.repository.UserRepository;
import com.smartHotelBooking.smartHotelBooking.service.impl.UserServiceImpl;
import com.smartHotelBooking.smartHotelBooking.util.JwtUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserServiceImpl userService;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;

    @GetMapping("/welcome")
    public String welcome() {
        return "This route is working.";
    }

     @PostMapping("/register")
      public ResponseEntity<String> registerUser(@Valid @RequestBody UserRegistrationDTO userDto) {
                userService.registerUser(userDto);
                return ResponseEntity.ok("User registered Successfully");
      }

      @PostMapping("/login")
      public AuthResponseDTO authenticateAndGetToken(@RequestBody AuthRequestDTO authRequest) {
          Authentication authentication = authenticationManager.authenticate(
                  new UsernamePasswordAuthenticationToken(authRequest.getEmail(),authRequest.getPassword()));

                  if(authentication.isAuthenticated()) {
                      User user = userRepository.findByEmail(authRequest.getEmail())
                              .orElseThrow(() -> new BadCredentialsException("Invalid Credentials"));
                      return new AuthResponseDTO(jwtUtil.generateToken(authRequest.getEmail(), user.getRole().name()),(int) user.getUserId(), user.getRole().name());
                  }

          throw new BadCredentialsException("Authentication failed.");
      }
}

package com.smartHotelBooking.smartHotelBooking.service.impl;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.RoomRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.RoomResponseDTO;
import com.smartHotelBooking.smartHotelBooking.entity.Hotel;
import com.smartHotelBooking.smartHotelBooking.entity.Room;
import com.smartHotelBooking.smartHotelBooking.repository.HotelRepository;
import com.smartHotelBooking.smartHotelBooking.repository.RoomRepository;
import com.smartHotelBooking.smartHotelBooking.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RoomServiceImpl implements RoomService {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private HotelRepository hotelRepository;

    @Override
    public RoomResponseDTO createRoom(RoomRequestDTO roomRequestDTO) {
        Hotel hotel = hotelRepository.findById(roomRequestDTO.getHotelId())
                .orElseThrow(() -> new RuntimeException("Hotel not found"));

        Room room = new Room();
        room.setType(roomRequestDTO.getType());
        room.setPrice(roomRequestDTO.getPrice());
        room.setAvailability(roomRequestDTO.isAvailability());
        room.setFeatures(roomRequestDTO.getFeatures());
        room.setHotel(hotel);

        Room saved = roomRepository.save(room);
        return mapToDTO(saved);
    }

    @Override
    public RoomResponseDTO updateRoom(Long roomId, RoomRequestDTO roomRequestDTO) {
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));

        room.setType(roomRequestDTO.getType());
        room.setPrice(roomRequestDTO.getPrice());
        room.setAvailability(roomRequestDTO.isAvailability());
        room.setFeatures(roomRequestDTO.getFeatures());

        if (roomRequestDTO.getHotelId() != null) {
            Hotel hotel = hotelRepository.findById(roomRequestDTO.getHotelId())
                    .orElseThrow(() -> new RuntimeException("Hotel not found"));
            room.setHotel(hotel);
        }

        Room updated = roomRepository.save(room);
        return mapToDTO(updated);
    }

    @Override
    public void deleteRoom(Long roomId) {
        roomRepository.deleteById(roomId);
    }

    @Override
    public RoomResponseDTO getRoomById(Long roomId) {
        return roomRepository.findById(roomId)
                .map(this::mapToDTO)
                .orElseThrow(() -> new RuntimeException("Room not found"));
    }

    @Override
    public List<RoomResponseDTO> getAllRooms() {
        return roomRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<RoomResponseDTO> getRoomsByHotel(Long hotelId) {
        return roomRepository.findByHotel_HotelId(hotelId).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<RoomResponseDTO> filterByPrice(Double min, Double max) {
        return roomRepository.findByPriceBetween(min, max).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<RoomResponseDTO> getAvailableRooms() {
        return roomRepository.findByAvailabilityTrue().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    private RoomResponseDTO mapToDTO(Room room) {
        return new RoomResponseDTO(
                room.getRoomId(),
                room.getType(),
                room.getPrice(),
                room.isAvailability(),
                room.getFeatures(),
                room.getHotel().getHotelId()
        );
    }
}

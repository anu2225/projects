package com.smartHotelBooking.smartHotelBooking.service.impl;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.UserRegistrationDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.RoomResponseDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.UserResponseDTO;
import com.smartHotelBooking.smartHotelBooking.entity.*;
import com.smartHotelBooking.smartHotelBooking.entity.enums.Role;
import com.smartHotelBooking.smartHotelBooking.repository.UserRepository;
import com.smartHotelBooking.smartHotelBooking.service.UserService;
import com.smartHotelBooking.smartHotelBooking.util.UserInfoDetails;
import jakarta.validation.Valid;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService, UserDetailsService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
           User user = userRepository.findByEmail(username)
                       .orElseThrow(() -> new UsernameNotFoundException("User not found " + username));

           if(!user.isActive() && user.getRole() != Role.ADMIN) {
               throw new BadCredentialsException("Account is inactive");
           }

           return new UserInfoDetails(user);
    }


    @Override
    public void registerUser(@Valid UserRegistrationDTO request) {
        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(request.getRole() != null ? request.getRole() : Role.USER);
        user.setContactNumber(request.getContactNumber());


        userRepository.save(user);
    }

    @Override
    public UserResponseDTO getUserById(int id) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
        return mapToDTO(user);
    }

    @Override
    public List<UserResponseDTO> getAllUsers() {
        return userRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    private UserResponseDTO mapToDTO(User user) {
        return new UserResponseDTO(
                user.getUserId(),
                user.getName(),
                user.getEmail(),
                user.getRole(),
                user.getContactNumber()
        );
    }

//    @Override
//    public List<Booking> getAllBookings() {
//        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
//        if(email == null) {
//            throw new BadCredentialsException("User not logged in");
//        }
//        return userRepository.findBookingsByUserEmail(email);
//    }

//    @Override
//    public List<Payment> getAllPayments() {
//        String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
//        if(email == null) {
//            throw new BadCredentialsException("User not logged in");
//        }
//        return userRepository.findPaymentsByUserEmail(email);
//    }

}

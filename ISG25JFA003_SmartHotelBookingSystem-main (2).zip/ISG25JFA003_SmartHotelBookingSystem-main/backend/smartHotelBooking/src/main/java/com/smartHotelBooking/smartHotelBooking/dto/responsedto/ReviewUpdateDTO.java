package com.smartHotelBooking.smartHotelBooking.dto.responsedto;

import lombok.Data;

@Data
public class ReviewUpdateDTO {
    private String response;
}

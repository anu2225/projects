package com.smartHotelBooking.smartHotelBooking.entity.enums;

public enum Action {
    EARN,
    REDEEM
}

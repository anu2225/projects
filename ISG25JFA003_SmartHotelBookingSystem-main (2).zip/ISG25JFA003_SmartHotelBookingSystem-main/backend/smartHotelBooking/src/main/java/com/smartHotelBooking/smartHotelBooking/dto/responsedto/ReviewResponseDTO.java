package com.smartHotelBooking.smartHotelBooking.dto.responsedto;

import com.smartHotelBooking.smartHotelBooking.entity.Review;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ReviewResponseDTO {
    private Long reviewId;
    private Long userId;
    private Long hotelId;
    private double rating;
    private String comment;
    private String response;
    private LocalDateTime timestamp;
    public ReviewResponseDTO(Review review) {
        this.reviewId = review.getReviewId();
        this.userId = review.getUser().getUserId();
        this.hotelId = review.getHotel().getHotelId();
        this.rating = review.getRating().intValue();
        this.comment = review.getComment();
        this.response = review.getResponse();
        this.timestamp = review.getTimestamp();
    }

}

package com.smartHotelBooking.smartHotelBooking.service;

import com.smartHotelBooking.smartHotelBooking.dto.requestdto.PaymentRequestDTO;
import com.smartHotelBooking.smartHotelBooking.dto.responsedto.PaymentResponseDTO;
import com.smartHotelBooking.smartHotelBooking.entity.Payment;

import java.util.List;

public interface PaymentService {

    void processPayment(PaymentRequestDTO paymentRequest);

    PaymentResponseDTO getPaymentById(String paymentId);

    PaymentResponseDTO getPaymentByBookingId(String bookingId);

    void deletePayment(String paymentId);

    List<Payment> getAllPayments();
}